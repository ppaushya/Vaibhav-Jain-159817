package com.demo.validate;

public class Validation {

	int count =100;
	static int num=1001;
    public void demo()
    {
    	System.out.println("instance variable");
    	System.out.println("number"+ num);
    	System.out.println("count"+count);
    }
    public static void show()
    {
    	System.out.println("Static member");
    }
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
