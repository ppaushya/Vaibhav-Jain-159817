package org.cap.demo;

public class InvalidAmountException extends Exception {
  public InvalidAmountException(String msg) {
	  super(msg);
  }
}
