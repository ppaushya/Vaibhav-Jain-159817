package org.cap.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
           File file=new File("C:\\demo\\filedemo\\mydemo.txt");
           char[] ch=new char[20];
           char a[]=new char[20];
           try(FileReader reader=new FileReader(file)){
        	    
        		   for(int c:ch)
        		   ch[c]=(char) reader.read();
        		   System.out.print((char[])ch+"\n");
        		   
        	        
           } catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
