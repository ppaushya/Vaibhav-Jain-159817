import { Component } from "@angular/core";

@Component({
    templateUrl:'./CreateAccount.component.html',
    styleUrls:['./CreateAccount.component.css']
})
export class CreateAccountComponent{

}