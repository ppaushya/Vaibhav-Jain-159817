package org.cap.date;

public class Stringconstant {

	public static void main(String[] args) {
		Integer num=100;
		Integer mynum=new Integer(100);
		Integer value=100;
		Integer myvalue=new Integer(100);
		System.out.println(num.equals(mynum)); //comparing the value
		System.out.println(num==mynum); ///memory comaprison
		System.out.println(num.equals(value)); //comparing the value
		System.out.println(num==value); ///memory comaprison
		System.out.println(mynum.equals(myvalue)); //comparing the value
		System.out.println(mynum==myvalue); ///memory comaprison


	}

}
