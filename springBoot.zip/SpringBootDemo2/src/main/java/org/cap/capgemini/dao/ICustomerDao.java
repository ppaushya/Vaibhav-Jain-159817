package org.cap.capgemini.dao;

import java.util.List;

import org.cap.capgemini.model.Register;



public interface ICustomerDao {

	public List<Register> getAllCustomers();

	public void updateCustomer(Register register);

	public boolean createCustomer(Register register);

	public void deleteCustomer(Integer customerId);

	public Register findCustomer(Integer customerId);

	public boolean isValidLogin(Register rPojo);

	
}
