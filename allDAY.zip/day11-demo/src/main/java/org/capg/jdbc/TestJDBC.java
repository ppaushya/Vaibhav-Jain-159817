package org.capg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TestJDBC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			String sql="create table employee(empid int primary key,firstName varchar(25) not null,lastName varchar(25),salary numeric(8,2),empdoj date)";
			Statement statement=connection.createStatement();
			boolean flag=statement.execute(sql);
			if(!flag)
			{
				System.out.println("Table Created Successfully");
			}
		
		} catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			
		}finally {
			try {
				connection.close();
			}catch(SQLException s) {
				s.printStackTrace();
			}
		}
              

	}

}
