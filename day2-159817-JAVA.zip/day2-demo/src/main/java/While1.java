import java.util.Scanner;

public class While1 {

	public static void main(String[] args) {
		int a,sum,num=1;
		int count=5;
		while(num<=100)
		{
		  if(num%2==0) {
			  System.out.print(num +",");
		  count--;
		  }
		  if(count==0) {
			  count=5;
			  System.out.println();
		  }
		  num++;
		}
	}

}
