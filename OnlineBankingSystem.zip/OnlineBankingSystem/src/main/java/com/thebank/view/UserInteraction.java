package com.thebank.view;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.Customer;
import com.thebank.model.User;
import com.thebank.service.IUserService;
import com.thebank.service.UserServiceImpl;
import com.thebank.util.Utility;

public class UserInteraction {

	Scanner scanner = new Scanner(System.in);
	int option;

	public void getLoginDetails() {
		
		IUserService userService=new UserServiceImpl();
		System.out.println("Enter userId");
		long userId=scanner.nextLong();
		if(Utility.isValidUser(String.valueOf(userId))) {
			User user=userService.userExists(userId);
			Customer customer=userService.getCustomer(user.getCustomerId());//Fetch complete details including account set using getCustomer function
			if(user!=null) {
				System.out.println("Do you remember your password:[Y/N]");
				String str=scanner.next();
				if(str.charAt(0)=='Y'||str.charAt(0)=='y') {
					System.out.println("Enter password: ");
					String loginPwd=scanner.next();
					 if(user.getLoginPassword()==loginPwd)
					 {
						 
						 System.out.println("Hello!"+customer.getCustomerName());
						 do{
					     System.out.println("1.View mini/Detailed Statement");
						 System.out.println("2.Change in address/mobile Number");
						 System.out.println("3.Request for Cheque Book");
						 System.out.println("4.Track Service Request");
						 System.out.println("5.Funds Transfer");
						 System.out.println("6.Change Password");
						 System.out.println("Choose your Option:");
						 int option=scanner.nextInt();
						 switch(option)
						    {
						    case 1:
						    case 2:
						    case 3:
						    case 4:
						    case 5:
						    	   List<Account> accounts= customer.getAccounts();						    	   								   
								   UserInteraction.printAccounts(accounts);
								   System.out.println("Enter accountId to transfer funds from");
								   long fromAccountId=scanner.nextInt();
								   
						             Account account=userService.ifAccountFound(customer,fromAccountId);
						              if(account==null)
						             {
						                 System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
						                 break;
						             }
						              System.out.println("Enter accountId to which you want to transfer funds");
						              long toAccountId=scanner.nextInt();
						            
						             //System.out.println("Choose account to credit funds:");
						            					             //int fromAccountNumber=sc.nextInt();
						             Account account=userService.ifAccountFoundTo(toAccountId);
						              if(account==null)
						             {
						                 System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
						                 break;
						             }
						             transaction.setFromAccount(account);
						             transaction.setTransactionType("Fund Transfer");
						             
						             System.out.println("Enter amount to transfer");
						             amount=scanner.nextDouble();
						    case 6:
						    	do{
						    		System.out.println("Enter new password");
									String pwd=scanner.next();
								   	System.out.println("Confirm password");
								   	String confirmPwd=scanner.next();
								   	if(pwd.equals(confirmPwd))
							    		userService.changePassword(pwd);
							    }while(true);
						    }
						 
						 }while(option.charAt(0)=='y'|| option.charAt(0)=='Y');
					 }
					
					
					
			}
				else("")//forgot password snippet-secret question
			
			else {
				System.out.println("User does not exist!");
			}//insert into loop again
		
			
			//if(str.charAt(0)=='Y'||str.charAt(0)=='y') {
				//enter password
				//System.out.println("Enter the login password:");
				//String loginPwd=scanner.next();
				}
			else("") // forgot pass snippet
			else//not a valid user
			
		}
	}

	private static void printAccounts(List<Account> accounts) {
		System.out.println("AccountId\tAccount Type\t Account_balance\t Account OpeningDate");
		System.out.println("------------------------------------------------------------------------------------------------------");
		 for(Account account:accounts)
		 {
			 System.out.println(account.getAccountId()+"\t\t"+account.getAccountType()+"\t\t"+account.getAccountBalance()+"\t\t"+account.getOpenDate()); 
		 }
		
	}
}
