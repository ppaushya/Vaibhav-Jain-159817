
public class parent extends grandparent{
	
	int num=400;
	
	public parent(int num,int num1) {
		super(num1);
		this.num = num1;
	}

	public void show()
	{
		System.out.println(num);
		super.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
