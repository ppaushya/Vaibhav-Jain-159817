import { Component } from '@angular/core';

@Component({
  selector: 'rm-root',
  template:
  `<div><h1>{{pageTitle}}</h1>
    <div>My First Component</div>
  </div>`,
  styleUrls: ['./test.component.css']
})
export class TestComponent {
  title = 'Angular: Getting Finished';
}
