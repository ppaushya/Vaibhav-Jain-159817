package com.capg.BankingVJSpringBoot.service;

import java.util.List;

import com.capg.BankingVJSpringBoot.model.Account;

public interface IAccountService {

	public boolean addAccount(Account account);

	public List<Account> getAccountByCustomerCustomerId(Long customerId);

	public List<Account> getAllAccounts();

}
