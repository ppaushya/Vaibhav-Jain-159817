package com.thebank.boot;

import com.thebank.view.MenuUI;
import com.thebank.view.PromptUI;
import com.thebank.view.ServiceUI;
import com.thebank.view.UserInteraction;

//Application starts
public class BootClass {

	public static void main(String[] args) {
				
		do {
			int choice = MenuUI.getTaskType();  //Identify user as Admin or customer
			switch(choice) {
				case 1:									//Customer login
					UserInteraction.doCustomerTasks(); //Prompt Customer login and associated functionality module
					break; 		
				case 2:			
					if(PromptUI.checkAdminPassword()) {//Admin login
						UserInteraction.doAdminTasks(); //Prompt Customer login and associated functionality module
					}
					break;
				case 3:
					ServiceUI.signUp(); //Prompt signup module
					break;
				case 4:
					System.out.println("Thank you! Have a nice Day :)"); 
					System.exit(0); //Application exit
					break;
			}
		}while(MenuUI.getRepeatConfirmation()); //Prompt user identification again if wrong choice entered
		System.out.println("Thank you! Have a nice Day :)");
	}
}