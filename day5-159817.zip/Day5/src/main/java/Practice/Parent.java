package Practice;

public class Parent extends GrandParent{

	
	String name="tom";
	public Parent()
	{//super() bydefault inserted by JVM
		System.out.println("Parent");
	}
	public void show()
	{
		
		System.out.println(super.num);
		System.out.println("Parent");
	}

}
