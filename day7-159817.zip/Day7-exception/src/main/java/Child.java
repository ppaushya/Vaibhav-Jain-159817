
public class Child extends Parent  {
	


	@Override
	public void show() throws NumberFormatException, ArithmeticException {
		// TODO Auto-generated method stub
		super.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
