
public class LibraryMethods {

	public static void main(String[] args) {
		String str = "Welcome to string handling tutorial";
		String str1="Hello! Folks!";
		char ch1 = str.charAt(0);
		char ch2 = str.charAt(5);
		int ch3 = str.codePointAt(5);
		int b=compareTo(str,str1);
		System.out.println("Character at 0 index is: "+ch1);
		System.out.println("Character at 5th index is: "+ch2);
		System.out.println("Character at 5th index is: "+ch3);
		System.out.println(b);
		int a=factorial()
        
	}

}
