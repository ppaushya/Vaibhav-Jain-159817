import { Component } from "@angular/core";

@Component({
    templateUrl:'./DepositWithdraw.component.html',
    styleUrls:['./DepositWithdraw.component.css']
})
export class DepositWithdrawComponent{

}