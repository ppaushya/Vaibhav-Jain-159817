
public class Array {

	public static void main(String[] args) {
	      //=new int[10];
	     int[] num= {1,2,3,4,5};
	     double pi=3.14145;
	     short mynum=80;
	    System.out.println("length : "+num.length );
	     num[0]=1;
	     num[1]=mynum;
	     num[2]=(int)pi;
	     
	     //System.out.println(num);
          for(int i=0;i<10;i++)
        	  System.out.println(num[i]);
	}

}
