package org.cap.demo;

public class Address {
	private String addressLine;
	public Address()
	{
		
	}
	
	public Address(String string)
	{
		this.addressLine=string;
	}

	
	
	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

}
