function createCustomer(custId,custName,regFees,address){
	this.custId=custId;
	this.custName=custName;
	this.regFees=regFees;
	this.address=address;
	
	this.printDetails=function(){
		console.log(custId+'-'+custName+'-'+regFees+'-'+address)
	}
}

var customer=new createCustomer(121,'Tom',20000,'23 NorthAvenue')

customer.printDetails()
