package org.capg.dao;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;

public interface IAccountDao {

	public Account createAccount(Account account);

	public List<Account> getAllAccounts(Customer customer);

	public Account getAccount(int accountNo);

	public List<Account> getAlltoAccounts(Customer customer);

	public List<Account> getAccountsForCustomer(int custId);

}
