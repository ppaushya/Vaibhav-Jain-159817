package org.cap.service;

import java.util.List;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface ICustomerService {
	public List<Customer> getAllCustomer();
	public void CreateCustomers(Customer customer);
	//public void getAccountDetails(Set<Account> account);
    public Customer ifFound(int customerID);
    public void addAccount(Customer customer,Account account);

}
