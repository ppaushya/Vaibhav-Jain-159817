package org.cap.date;
import java.util.Date;

public class Datedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date dd=new Date(2018-1900,01,20);
		System.out.println(dd);
		Date cc=new Date();
		System.out.println(cc);
		System.out.println(cc.getDate());
		System.out.println(cc.getDay());
		System.out.println(cc.after(dd));
		System.out.println(cc.before(dd));
		

	}

}
