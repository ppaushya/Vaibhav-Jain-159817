package org.cap;

import java.util.Scanner;

public class Employee {

	int empID;
	String firstname;
	String lastname;
	int age;
	double salary;
	Weekdays weekOff;
	
	public void getEmployee()
	{
		/*empID=1000;
		firstname="Jones";
		lastname="Marcus";
		age=34;
		salary=23000;
		weekOff=Weekdays.SAT;*/
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the details of Employee:");
		int  empId=sc.nextInt();
		 firstname=sc.next();
		lastname=sc.next();
			 age=sc.nextInt();
				salary=sc.nextInt();
				int a=sc.nextInt();
				  switch(a)
				  {
				  case 2:
					  weekOff=Weekdays.MON;
				  case 3:
					  weekOff=Weekdays.TUE;
				  case 4:
					  weekOff=Weekdays.WED;
				  case 5:
					  weekOff=Weekdays.THUR;
				  case 6:
					  weekOff=Weekdays.FRI;
				  case 7:
					  weekOff=Weekdays.SAT;
				  case 1:
					  weekOff=Weekdays.SUN;
				 }
			      		     
				
				
		
	}
	public void print()
	{
		System.out.println(empID+"-"+firstname+"-"+lastname+"-"+salary+"-"+age+"-"+weekOff);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee obj=new Employee();
		obj.getEmployee();
		obj.print();

	}

}
