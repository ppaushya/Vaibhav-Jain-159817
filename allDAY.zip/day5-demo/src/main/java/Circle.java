
public class Circle extends Shape {
     double pi=3.14;
     double radius=5.78;
     
     public double CalculateArea()
     {
    	 return pi*radius*radius;
     }
     
     public void draw() {
    	 System.out.println("Circle printed");
     }
     
}
