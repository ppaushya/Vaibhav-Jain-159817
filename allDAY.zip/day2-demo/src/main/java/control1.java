
public class control1 {

	public void testIf()
	{
		for(int i=0;i<5;i++)
		{
			if(i==3)
				System.out.println("It's Done!");
			else
				System.out.println("It's not!");
		}
	}
	public static void main(String[] args) {
		control1 obj=new control1();
		obj.testIf();

	}

}
