import java.util.Scanner;

public class Employee extends Person {
	
	double salary;
	int empID;
    
    public Employee()
    {
   	 
    }
    
	
	 public Employee(int personID, String firstname,String lastname,double salary, int empID) {
		super(personID,firstname,lastname);
		 this.salary = salary;
		this.empID = empID;
	}
	public void getEmployee()
	 {
		 Scanner scan=new Scanner(System.in);
		 
		 salary=scan.nextDouble();
		 empID=scan.nextInt();
		 scan.close();
		 
	 }
	public void show()
	{
		System.out.println("Person cklass--> Show method");
	}
	 public void showEmployee()
	 {
		
		 System.out.println(salary+","+empID);
	 }

	public static void main(String[] args) {
       //  Person obj=new Employee();
      //   Employee emp1= new Employee(2000,"fhgj","tyur",34000,567);
       Person per=new Employee();
	 per.show();
       //  obj.getEmployee();
         //obj.showPerson();
      //  obj.showEmployee();
	}

}
