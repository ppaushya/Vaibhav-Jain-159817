import { Component } from "@angular/core";

@Component({
    templateUrl:'./TransactionSummary.component.html',
    styleUrls:['./TransactionSummary.component.css']
})
export class TransactionSummaryComponent{

}