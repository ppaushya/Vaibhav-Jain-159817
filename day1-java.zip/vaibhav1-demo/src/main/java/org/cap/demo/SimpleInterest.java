package org.cap.demo;

import java.util.Scanner;

public class SimpleInterest {

	 float principle;
	 float years;
	 float rate_of_interest;
	 float simpleinterest;
	 public void getData() {
		 /*principle=4000;
		 years=3.3f;
		 rate_of_interest=0.0665f;*/
		 Scanner scanner=new Scanner(System.in);
		 System.out.println("Enter Principle:" );
		 principle=scanner.nextFloat();
		 
		 System.out.println("Enter Years:" );
		 principle=scanner.nextFloat();
		 
		 System.out.println("Enter Rate of Interest:" );
		 principle=scanner.nextFloat();
		 scanner.close();
		 
	 }
	 
	 public double calculateInterest()
	 {
		 return principle*years*rate_of_interest;
		 
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
