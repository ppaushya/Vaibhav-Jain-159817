package org.cap.demo;

import java.util.Scanner;

public class Employee {
	int empID;
	String empName;
	int age;
	boolean isPermanent;
	String gender;
	String address;
	public void getEmployee()
	{
		 Scanner scanner=new Scanner(System.in);
		 System.out.println("Enter empID:" );
		 empID=scanner.nextInt();
		 
		 System.out.println("Enter empName:" );
		 empName=scanner.next();
		 
		 System.out.println("Age:" );
		 age=scanner.nextInt();
		 
		 System.out.println("Enter isPermanent:" );
		 isPermanent=scanner.nextBoolean();
		 
		 System.out.println("Enter Gender:" );
		 gender=scanner.next();
		 
		 System.out.println("Address:" );
		 address=scanner.next();
		 scanner.close();
		 
	}
	public void printEmployee()
	{
	  System.out.println("Employee Details: \n EmpID: " + empID + "\n EmpName: "+ empName +"\nAge: "+ age +"\nIspermanent: "+ isPermanent + "\nGender: " + gender+ "\nAdress: " +address);	
	}

	public static void main(String[] args) {
	   Employee obj=new Employee();
	   obj.getEmployee();
	   obj.printEmployee();

	}

}
