package com.capstore.service;

import java.util.List;
import java.util.Map;
import com.capstore.model.Product;
import com.capstore.model.SalesAnalysis;

public interface IProductService {

	public List<Product> getAllProducts();
	public List<Product> sortBestSeller(String category);
	public Map<String, Long> getProductQuantity();
	public Map<String, Integer> getBestSellerId();
	public Map<String, Long> getProductSales();
	public List<SalesAnalysis> getSalesAnalysis();
}
