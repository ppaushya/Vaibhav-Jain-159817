
public class Stringclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String str="Tom";
     String tre="Jerry";
     String myStr=new String("Jerry");
     String my=new String("Jerry");
     System.out.println(str.hashCode());
     System.out.println(myStr.hashCode());
     System.out.println(tre.hashCode());
     System.out.println(my.hashCode());
	}

}
