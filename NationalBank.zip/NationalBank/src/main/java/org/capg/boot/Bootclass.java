package org.capg.boot;

import org.capg.model.Customer;
import org.capg.view.UserInteraction;

public class Bootclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInteraction userinteraction=new UserInteraction();
		Customer customers=userinteraction.getCustomerDetails();

	}

}
