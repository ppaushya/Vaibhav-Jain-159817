import java.util.Scanner;

public class missingelement {

	int[] Myarr;
	public void getElements(int size)
	{
		 Scanner sc=new Scanner(System.in);
			System.out.println("enter  "+ size +" Array elements");
			Myarr=new int[size];
			for(int i=0;i<size;i++)
				Myarr[i]=sc.nextInt();
			sc.close();
	}
	 public void printArray()
	    {
	    	for(int i=0;i<Myarr.length;i++)
	    		System.out.println(Myarr[i]);
	    }
	 public void sortArray()
	    {
	    	for(int i=0;i<Myarr.length;i++)
	    	{
	    		for(int j=i+1;j<Myarr.length;j++)
	    		{
	    			if(Myarr[i]>Myarr[j])
	    			{
	    				int temp=Myarr[i];
	    				Myarr[i]=Myarr[j];
	    				Myarr[j]=temp;
	    			}
	    			
	    		}
	    	}
	    	System.out.println("Sorted Array is :");
	    }
	 public void findMissing()
	 {
		 int flag=0;
		 int end=Myarr.length;
		 for(int i=0;i<end-1;i++)
		 {
			 if((Myarr[i+1]-Myarr[i])>1)
			 {
				 System.out.println();
			 }
				 
		 }
	 }
	    
	public static void main(String[] args) {
	

	}

}
