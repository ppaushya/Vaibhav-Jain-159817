package org.cap.main;


import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {

	public static void main(String[] args) {
		String CustomerID;
		String CustomerName;
		String emailID;
		String MobileNo;
		String AccountNo;
		String openingDate;
		
		Pattern pattern;
		Matcher matcher;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter CustomerID: ");
		CustomerID=sc.next();
		pattern=Pattern.compile("[0-9]{6}{10}");
		matcher=pattern.matcher(CustomerID);
		while(!matcher.find()) {
			System.out.println("Enter CustomerID Again:");
			CustomerID=sc.next();
			matcher=pattern.matcher(CustomerID);
			
		}
		System.out.println("Enter Customer Name: ");
		CustomerName=sc.next();
		pattern=Pattern.compile("^[A-Za-z]");
		matcher=pattern.matcher(CustomerName);
		while(!matcher.find()) {
			System.out.println("Enter CustomerName Again:");
			CustomerName=sc.next();
			matcher=pattern.matcher(CustomerName);
		}
		
		System.out.println("Enter emailID: ");
		emailID=sc.next();
		pattern=Pattern.compile("[a-z0-9._-]@[a-z0-9.-].[a-z]{2,}");
		matcher=pattern.matcher(emailID);
		while(!matcher.find()) {
			System.out.println("Enter emailID Again:");
			emailID=sc.next();
			matcher=pattern.matcher(emailID);
			
		}
	  
		System.out.println("Enter Mobile Number: ");
		MobileNo=sc.next();
		pattern=Pattern.compile("[789]{1}[0-9]{9}");
		matcher=pattern.matcher(MobileNo);
		while(!matcher.find()) {
			System.out.println("Enter Mobile Number Again:");
			MobileNo=sc.next();
			matcher=pattern.matcher(MobileNo);
			
		}
		
		System.out.println("Enter Account Number: ");
		AccountNo=sc.next();
		pattern=Pattern.compile("[0-9]{3}{6}");
		matcher=pattern.matcher(AccountNo);
		while(!matcher.find()) {
			System.out.println("Enter Account Number Again:");
			AccountNo=sc.next();
			matcher=pattern.matcher(AccountNo);
			
		}
		System.out.println("Enter opening Date: ");
		openingDate=sc.next();
		pattern=Pattern.compile("[0-9]{2}-[0-9]{1}|[012]{1}-[0-9]{4}");
		matcher=pattern.matcher(openingDate);
		while(!matcher.find()) {
			System.out.println("Enter opening Date Again:");
			openingDate=sc.next();
			matcher=pattern.matcher(openingDate);
			
		}
		
		
		
		

	}

}
