package com.capg.BankingVJSpringBoot.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.BankingVJSpringBoot.model.Account;

@Repository("accountDao")
@Transactional
public interface IAccountDao extends JpaRepository<Account, Long>{

	public List<Account> getAccountByCustomerCustomerId(Long customerId);
	public List<Account> getAccountNumberByCustomerCustomerId(Long customerId);
	public List<Account> getAccountNotByCustomerCustomerId(Long customerId);

}
