package Exercise;

public class SalaryWorker extends Worker{

	public SalaryWorker(String name,int hrs )
	{
		super( name, hrs);
	}
	public float comPay(int hrs)
	{
		return 40*getSalaryRate();
	}
}
