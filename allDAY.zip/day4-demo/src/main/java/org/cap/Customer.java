package org.cap;


enum custType{
	SILVER(0,100),GOLD(101,200),DIAMOND(201,300),PLATINUM(301,500);
	int reward;
	int minreward;
	int maxreward;
	private custType(int minreward,int maxreward)
	{
		this.minreward=minreward;
		this.maxreward=maxreward;
	}
	public int getminrew() {
		return this.minreward;
	}
	public int getmmaxrew() {
		return this.maxreward;
	}
}
public class Customer {
	String custname="Jones";
	int custID=101;
     custType Type=custType.DIAMOND;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer obj=new Customer();
		
	///	System.out.println(obj.custID+"-"+obj.custname+"-"+ obj.custType+"-"+obj.custType.getminrew()+"-"+obj.custType.getmaxrew());
		
		

	}

}
