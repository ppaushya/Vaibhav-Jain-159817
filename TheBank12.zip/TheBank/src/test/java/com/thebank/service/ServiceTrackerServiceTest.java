package com.thebank.service;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.thebank.dao.IServiceTrackerDao;
import com.thebank.model.ServiceTracker;

public class ServiceTrackerServiceTest {

	@Mock
	IServiceTrackerDao serviceTrackerDao;

	static IServiceTrackerService trackerServices;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		trackerServices = new ServiceTrackerService(serviceTrackerDao);
	}

	@Test(expected = IllegalArgumentException.class)
	public void test_null_serviceTracker_creation() {
	 ServiceTracker serviceTracker= new ServiceTracker();
	 serviceTracker = null;
	 trackerServices.addServiceTracker(serviceTracker);

	}

	@Test
	public void test_createPayee_successful() {
		ServiceTracker serviceTracker= new ServiceTracker(1001,"ServiceReceived",123,LocalDate.now(),"Request");

		Mockito.when(serviceTrackerDao.addServiceTracker(serviceTracker)).thenReturn(true);
		trackerServices.addServiceTracker(serviceTracker);

		Mockito.verify(serviceTrackerDao).addServiceTracker(serviceTracker);

	}


}
