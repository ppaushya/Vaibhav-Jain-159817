package com.capg.BankingVJSpringBoot.service;

import com.capg.BankingVJSpringBoot.model.Customer;

public interface ILoginService {

	public Customer isValidLogin(Customer customer);

}
