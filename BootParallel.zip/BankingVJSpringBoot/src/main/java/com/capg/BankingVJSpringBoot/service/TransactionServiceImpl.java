package com.capg.BankingVJSpringBoot.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.BankingVJSpringBoot.dao.IAccountDao;
import com.capg.BankingVJSpringBoot.dao.ITransactionDao;
import com.capg.BankingVJSpringBoot.model.Transaction;

@Service("transactionService")
public class TransactionServiceImpl implements ITransactionService{

	@Autowired
	private ITransactionDao transactionDao;
	
	@Autowired
	private IAccountDao accountDao;

	@Override
	public boolean createTransaction(Transaction transaction) {
		if(transaction.getTransactionType().equals("withdrawal")
				|| transaction.getTransactionType().equals("fund transfer")) {
			IAccountService accountService = new AccountServiceImpl();
			double balance = accountService.getCurrentBalanceOfAccount(transaction.getFromAccount());
			if(balance<transaction.getAmount()) {
				return false;
			}
		}
		transactionDao.save(transaction);
		return true;
	}

	@Override
	public List<Transaction> getAllTransactionsOfCustomer(Integer customerId) {
		List<Long> accountNumberList = accountDao.getAccountNumberByCustomerCustomerId(customerId);
		return transactionDao.getTransactionByFromAccountInOrToAccountIn(accountNumberList,accountNumberList);
	}

	@Override
	public List<Transaction> getAllTransactionsOfCustomerBetweenDates(Integer customerId, Date fromDate, Date toDate) {
		List<Long> list = new ArrayList<Long>();
		list.add(accountNumber);
		return transactionDao.getTransactionByFromAccountInOrToAccountIn(list,list);
	}

	@Override
	public List<Transaction> getAllTransactionsOfAccount(Integer accountId) {
		List<Long> accountNumberList = accountDao.getAccountNumberByCustomerCustomerId(customerId);
		List<Transaction> allList = transactionDao.getTransactionByFromAccountInOrToAccountIn(accountNumberList,accountNumberList);
		System.out.println("allList");
		System.out.println(allList);
		allList.removeIf(t -> (t.getTransactionDate().before(fromDate) || t.getTransactionDate().after(toDate)));
		return allList;
	}
}
