package org.cap.Boot;

import org.cap.model.Registration;
import org.cap.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		 UserInteraction userinteraction=new UserInteraction();
		 Registration customer=userinteraction.createCustomer();
		 
       
	}

}
