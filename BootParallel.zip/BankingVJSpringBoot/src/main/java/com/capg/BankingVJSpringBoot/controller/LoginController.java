package com.capg.BankingVJSpringBoot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.BankingVJSpringBoot.model.Customer;
import com.capg.BankingVJSpringBoot.service.ILoginService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class LoginController {
	
	@Autowired
	private ILoginService loginService;
	
	@PostMapping(value="/login")
	public ResponseEntity<Customer> insertLogin(@RequestBody Customer customer){
		Customer customer1=loginService.isValidLogin(customer);
		
		if(customer1==null)
		{
			return new ResponseEntity("Login Failed", HttpStatus.NOT_FOUND);
		}
		else 
			return new ResponseEntity<Customer>(customer1, HttpStatus.OK);
		
	}

}
