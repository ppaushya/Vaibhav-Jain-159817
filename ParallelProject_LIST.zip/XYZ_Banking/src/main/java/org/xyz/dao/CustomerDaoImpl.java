package org.xyz.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.xyz.model.Address;
import org.xyz.model.Customer;
import org.xyz.util.Validator;


public class CustomerDaoImpl implements ICustomerDao{

	private static List<Customer> customers = dummyDB();
	
	private static List<Customer> dummyDB() {
		List<Customer> customers = new ArrayList<Customer>();
		
		Address address1 = new Address("North Avenue","Cross St","Chennai","IN","122345");
		customers.add(new Customer(Validator.generateCustomerNumber(),"Sam","Rock",LocalDate.of(1990, 3, 15),"sam@gmail.com","8234567890",address1));
		
		Address address2 = new Address("South Avenue","Cross St","Chennai","IN","122345");
		customers.add(new Customer(Validator.generateCustomerNumber(),"Bob","Bill",LocalDate.of(2010, 9, 1),"bob@gmail.com","7519243565",address2));
		
		Address address3 = new Address("West car st","Cross St","Chennai","IN","122345");
		customers.add(new Customer(Validator.generateCustomerNumber(),"Ishan","Gupta",LocalDate.of(1990, 4, 30),"gupta@gmail.com","7583692140",address3));
		
		Address address4 = new Address("North Avenue","Cross St","Pune","IN","122345");
		customers.add(new Customer(Validator.generateCustomerNumber(),"Amit","Shah",LocalDate.of(1995, 5, 5),"shah@gmail.com","7234567890",address4));
		
		Address address5 = new Address("North Avenue","Cross St","Delhi","IN","122345");
		customers.add(new Customer(Validator.generateCustomerNumber(),"Kartik","Parmar",LocalDate.of(2000, 12, 19),"parmar@gml.com","9312456789",address5));
		
		return customers;
	}
	
	public List<Customer> getAllCustomers() {
		return customers;
	}

	public void createCustomer(Customer customer) {
		customer.setCustomerId(Validator.generateCustomerNumber());
		customers.add(customer);
		
	}

	public Customer getCustomerFromCustomerId(long customerId) {
		for(Customer customer:customers) {
			if(customer.getCustomerId()==customerId) {
				return customer;
			}
		}
		return null;
	}


}
