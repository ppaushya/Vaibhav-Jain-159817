
public class Sender<T,R> {
  T Message;
  R Description;
public T getMessage() {
	return Message;
}
public void setMessage(T message) {
	Message = message;
}
public R getDescription() {
	return Description;
}
public void setDescription(R description) {
	Description = description;
}

/*public T getMessage() {
	return Message;
}

public void setMessage(T message) {
	Message = message;
}*/
}
