package com.capg.BankingVJSpringBoot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.BankingVJSpringBoot.dao.ILoginDao;
import com.capg.BankingVJSpringBoot.model.Customer;

@Service("loginService")
public class LoginServiceImpl implements ILoginService{
	

	@Autowired
	private ILoginDao loginDao;

	@Override
	public Customer isValidLogin(Customer customer) {
		String userName=customer.getEmailId();
		String password=customer.getPassword();
		Customer customerLogin=loginDao.getCustomerByEmailIdAndPassword(userName,password);
		return customerLogin;
	}

}
