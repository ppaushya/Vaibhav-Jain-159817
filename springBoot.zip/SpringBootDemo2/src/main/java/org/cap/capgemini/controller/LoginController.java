package org.cap.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;




@Controller
public class LoginController {
	
@PostMapping("/validateLogin")
public String validateLogin(@RequestParam("userName") String userName,
		@RequestParam("userPassword")String userPassword,ModelMap map) {
	if(userName.equals("tom")&&userPassword.equals("tom123")) {
		map.addAttribute("userName", userName);
		return "success";
	}		
	
	
	return "redirect:/";
	
}
}