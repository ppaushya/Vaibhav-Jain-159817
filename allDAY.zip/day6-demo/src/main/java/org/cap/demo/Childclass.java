package org.cap.demo;

public class Childclass extends Abstractclass{
	
	public void print()
	{
		System.out.println("----------");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}