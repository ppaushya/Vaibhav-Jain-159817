package org.cap.service;

import org.cap.dao.IRegistrationDao;
import org.cap.dao.RegistrationDao;
import org.cap.model.Registration;

public class CustomerRegistrationImpl implements ICustomerRegistration {
      private IRegistrationDao customerdao=new RegistrationDao();
	
   
		
	private boolean isValidCustomer(Registration customer) {
          boolean flag=false;
		
		if(customer.getCustomerName().matches("[A-Za-z]{3,}")) {
			if(customer.getMobileNo().matches("[789]{1}[0-9]{9}")) {
				flag=true;
			}else
				flag=false;
		}else
			flag=false;
		return flag;
	}
	@Override
	public  void createCustomer(Registration customer) {
		if(isValidCustomer(customer))
		{
		     customerdao.createCustomer(customer);
		     
		}
		
	}
	

	
	
	

}
