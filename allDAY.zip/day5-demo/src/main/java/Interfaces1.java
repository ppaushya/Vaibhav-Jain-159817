
public interface Interfaces1 {

	 public final static int num=100;
	 public abstract void draw();
	 public abstract void info();
	 
	 public static void show()
	 {
		 System.out.println("Shape interface show method");
		 
	 }
	 default void shapepoints()
	 {
		 System.out.println("Shape interfaces points method");
	 }
	 private static void details()
	 {
		 System.out.println("-----Shape interface details method--------");
	 }
}
