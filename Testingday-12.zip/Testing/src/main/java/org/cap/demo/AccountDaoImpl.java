package org.cap.demo;

public class AccountDaoImpl implements IAccountDao{

	@Override
	public boolean addAccount(Customer customer) {
	
		return false;
	}
}
