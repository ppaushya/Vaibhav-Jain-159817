
public class Parent {
     public void show() throws NumberFormatException,ArithmeticException{
    	 
     } 
}
