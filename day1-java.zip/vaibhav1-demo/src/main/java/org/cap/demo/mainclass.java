package org.cap.demo;

public class mainclass {

	public static void main(String[] args) {
		SimpleInterest interest=new SimpleInterest();
		interest.getData();
	    Double si=interest.calculateInterest();
		System.out.println("Simple Interest: " +si);
				
		// TODO Auto-generated method stub

	}

}
