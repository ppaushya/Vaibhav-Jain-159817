import java.util.Scanner;

public class product {
      String name;
      int productID;
      int quantity;
      float price;
      float discount;
      float tax;
      
      public void getProductDetails()
      {
    	 Scanner sc=new Scanner(System.in);
 		 System.out.println("Enter Name: " );
 		 name=sc.next();
		 System.out.println("Enter productID:" );
		 productID=sc.nextInt();
		 System.out.println("Enter Quantity:" );
		 quantity=sc.nextInt();
		 System.out.println("Enter Price:" );
		 price=sc.nextFloat();
		 System.out.println("Enter Discount %:" );
		 discount=sc.nextFloat();
		 sc.close(); 
 	   }
      
      public float calculateDiscount()
      {
    	 float dis=(price*discount*quantity)/100;
    	 return dis;
      }
      
      public float calculateTax()
      {
    	 float taxamt;
    	  if(discount>0.90)
    		taxamt=0.01f;
    	 else if(discount>0.08 && discount<0.90)
    	   taxamt=0.12f;
    	 else if(discount>0.60 && discount<0.80)
      	   taxamt=0.20f;
    	 else if(discount>0.50 && discount<0.60)
      	   taxamt=0.25f;    
    	 else
    	 taxamt=0.40f;
    	  tax=price*quantity*taxamt;
    	  return tax;
      }
      
      public float finalPrice()
      {
    	  float a;
    	  return a= (price*quantity)+ calculateTax() - calculateDiscount();
      }
      
      
	public static void main(String[] args) {
		product obj=new product();
		obj.getProductDetails();
		System.out.println("Final Price : " +obj.finalPrice());
		
		// TODO Auto-generated method stub

	}

}
