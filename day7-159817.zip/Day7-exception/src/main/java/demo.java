
public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer num1=100;
		Integer num2=null;
		Integer ans=null;
		try {
			ans=num1+num2;
			try {
				String num="8s";
				int result=ans/Integer.parseInt(num);
				System.out.println("Result:"+result);
				}catch(NullPointerException n) {
					n.printStackTrace();
				}
		}

	}

}
