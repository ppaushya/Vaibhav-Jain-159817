package org.cap.model;

public enum AccountType {
	SAVINGS,RD,FD,CURRENT;

}
