package org.cap.test;

public interface LoginCategory {

}
