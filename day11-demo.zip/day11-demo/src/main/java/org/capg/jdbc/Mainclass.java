package org.capg.jdbc;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Mainclass {
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  UserInteraction userinteraction=new UserInteraction();
		  EmployeeDao dao=new EmployeeDaoImpl();
		  int option;
			String choice;
			do {
			System.out.println("1.Create Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Delete Employee");
			System.out.println("4.List All Employee");
			System.out.println("5.Find Employee");
			System.out.println("6.Exit");
			System.out.println("Enter your option:");
		     option=sc.nextInt();
				switch(option) {
				case 1: 
					Employee employee=new Employee(789, "Kamal", "jERRY", 23000, LocalDate.of(2010,3,12));
					Employee employee1=userinteraction.createEmployee();
					dao.createEmployee(employee1);
				case 2:
					 
					break;
				case 3:
					int empId=userinteraction.promptEmployeeID();
					dao.deleteEmployee(empId);
					break;
				case 4:
					List<Employee> employees= dao.getAllEmployees();
					userinteraction.printAllEmployees(employees);
					break;
				case 5:
					int empId1=userinteraction.promptEmployeeID();
					employee=dao.foundEmployee(empId1);
					
					break;
				case 6:
					System.exit(0);
				default:
					System.out.println("Sorry! Invalid Option!");
				}
				System.out.println("You wish to continue[y|n]:");
				choice=sc.next();
				
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');     
				}
				
	
 
   }
 

