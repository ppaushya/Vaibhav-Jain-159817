package org.cap.date;

public class Wrapperclass {

	public static void main(String[] args) {
		
		Integer integer=new Integer(23);
		int num=100;
		integer=num;
		System.out.println(integer);
		String str="123";
		int mynum=Integer.parseInt(str);
		System.out.println(mynum);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*System.out.println(integer);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Short.MAX_VALUE);
		System.out.println(Short.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MIN_NORMAL);
		System.out.println(Double.MAX_EXPONENT);*/
		
		
		
		// TODO Auto-generated method stub

	}

}
