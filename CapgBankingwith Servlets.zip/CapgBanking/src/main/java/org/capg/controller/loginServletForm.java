package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/loginServletForm")
public class loginServletForm extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		ILoginService loginService=new LoginServiceImpl();
		Customer customer=new Customer();
		customer.setFirstName(req.getParameter(customer.getFirstName()));
		customer.setLastName(req.getParameter(customer.getLastName()));
		String dob=req.getParameter("dateOfbirth");
		
		int year =Integer.parseInt(dob.substring(0,4));
		int month=Integer.parseInt(dob.substring(5, 7));
		int date=Integer.parseInt(dob.substring(8, 10));
		LocalDate dates=LocalDate.of(year, month, date);
		customer.setDateOfBirth(dates);
		customer.setEmailId(req.getParameter(customer.getEmailId()));
		customer.setMobile(req.getParameter(customer.getMobile()));
		customer.setuserPass(req.getParameter(customer.getuserPass()));
		
		Address address=new Address();
		customer.getAddress().setAddressLine1(req.getParameter(address.getAddressLine1()));
		customer.getAddress().setAddressLine2(req.getParameter(address.getAddressLine2()));
		customer.getAddress().setCity(req.getParameter(address.getCity()));
		customer.getAddress().setState(req.getParameter(address.getState()));
		customer.getAddress().setPincode(req.getParameter(address.getPincode()));
		
		boolean flag=loginService.createCustomer(customer);
		if(flag)
		{
			System.out.println("Record inserted");
		    resp.sendRedirect("Success");
		}
		else 
			resp.sendRedirect("registration.html");
		
		
		
	
	

}
}