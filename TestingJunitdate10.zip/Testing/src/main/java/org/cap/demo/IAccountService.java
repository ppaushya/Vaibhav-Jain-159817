package org.cap.demo;

public interface IAccountService {
	public Account createAccount(Customer customer,double amount) throws InvalidAmountException;

	public Account withdrawal(Account acc, int i);

	Account deposit(Account account, double amount);

	Account withdrawal(Account account, double amount);

}
