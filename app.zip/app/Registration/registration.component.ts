
import { Component, OnChanges, Input, EventEmitter,Output } from "@angular/core";

@Component({
 
    templateUrl:'./registration.component.html',
    styleUrls:['./registration.component.css']
})
export class RegistrationComponent {
    msg:string="Hi";
}