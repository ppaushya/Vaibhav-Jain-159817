package org.cap.date;

public class buffer12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder buffer=new StringBuilder(50);
		buffer.append("dfgfgfvfgh");
	//	StringBuffer buffer=new StringBuffer("Tom");
	//	System.out.println(buffer);
	//	System.out.println(buffer.length());
	//	System.out.println(buffer.capacity());
		
		//buffer.insert(0, "vudhufufudfjhvjhv");
		buffer.ensureCapacity(120);
		//buffer.replace(0, 3,"Jerry");
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());
		
	}

}
