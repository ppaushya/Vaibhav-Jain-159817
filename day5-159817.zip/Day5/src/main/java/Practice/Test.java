package Practice;
class Base
{
	public Base()
	{
		System.out.println("Base default constructor");
	}
	public void baseMethod()
	{
		
		System.out.println("Base");
	}
}
class Derived extends Base
{
	public Derived()
	{
		System.out.println("Derived default constructor");
	}
	public void derivedMethod()
	{
		super.baseMethod();
		System.out.println("Derived");
	}
}
public class Test {

	public static void main(String[] args) {
		Derived d=new Derived();
		/*output:
		Base default constructor//bcoz super() is called bydefault by JVM
		Derived default constructor*/
	
		d.derivedMethod();

	}

}
