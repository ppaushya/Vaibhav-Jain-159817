package org.cap.file;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class MainClass {
static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
          File file =new File("C:\\demo\\filedemo\\mydata.txt");
          String option;
          try(FileOutputStream stream=new FileOutputStream(file);
            		ObjectOutputStream outputstream=new ObjectOutputStream(stream)){
            	       
        	do {
        	  UserinteractionPro userinteraction=new UserinteractionPro();
        	  Product product=userinteraction.getProductDetails();
        	  outputstream.writeObject(product);
        	  System.out.println("Do you wish to Continue:y/n");
        	  option=sc.next();
        	  if(option.charAt(0)=='n'||option.charAt(0)=='N')
        	  {
        		  
        	  }
        	  
        	}while(option.charAt(0)=='y'||option.charAt(0)=='Y');
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  }
}
