package org.cap.capgemini.model;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Past;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Register {
	
	private int customerId;
	
	private String firstName;
	private String lastName;
	private String emailId;
	




	private String address;
	private String city;
	private String gender;
	private String qualification;
	
	
	@JsonFormat(pattern="dd-MM-yyyy")
	@Past
	private Date dateOfBirth;
	
	private String password;
	
	private String customerPwd;
	private int registrationFees;
	

	
	
	public Register() {
		
	}


	public String getEmailId() {
		return emailId;
	}




	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getCustomerId() {
		return customerId;
	}




	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}




	public String getFirstName() {
		return firstName;
	}




	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}




	public String getLastName() {
		return lastName;
	}




	public void setLastName(String lastName) {
		this.lastName = lastName;
	}




	public String getAddress() {
		return address;
	}




	public void setAddress(String address) {
		this.address = address;
	}




	public String getCity() {
		return city;
	}




	public void setCity(String city) {
		this.city = city;
	}




	public String getGender() {
		return gender;
	}




	public void setGender(String gender) {
		this.gender = gender;
	}




	public String getQualification() {
		return qualification;
	}




	public void setQualification(String qualification) {
		this.qualification = qualification;
	}




	public Date getDateOfBirth() {
		return dateOfBirth;
	}




	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}




	public String getPassword() {
		return password;
	}




	public void setPassword(String password) {
		this.password = password;
	}




	public String getCustomerPwd() {
		return customerPwd;
	}




	public void setCustomerPwd(String customerPwd) {
		this.customerPwd = customerPwd;
	}




	public int getRegistrationFees() {
		return registrationFees;
	}




	public void setRegistrationFees(int registrationFees) {
		this.registrationFees = registrationFees;
	}




	public Register(int customerId, String firstName, String lastName, String address, String city, String gender,
			String qualification, @Past Date dateOfBirth, String password, String customerPwd, int registrationFees) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.gender = gender;
		this.qualification = qualification;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
		this.customerPwd = customerPwd;
		this.registrationFees = registrationFees;
	}




	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", address=" + address + ", city=" + city + ", gender=" + gender + ", qualification=" + qualification
				+ ", dateOfBirth=" + dateOfBirth + ", password=" + password + ", customerPwd=" + customerPwd
				+ ", registrationFees=" + registrationFees + "]";
	}
	
	
	

}
