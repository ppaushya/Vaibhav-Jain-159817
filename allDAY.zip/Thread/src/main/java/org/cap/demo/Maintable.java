package org.cap.demo;

public class Maintable {

	public static void main(String[] args) {
          PrintTable print=new PrintTable();
          Thread t1=new Thread();
          {
        	  @Override
        	  public void run()
        	  {
        	     
        	  }
          }
          
          
       
         
          
	}

}
