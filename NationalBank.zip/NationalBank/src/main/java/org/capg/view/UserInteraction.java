package org.capg.view;

import java.util.Scanner;

import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.util.Utility;

public class UserInteraction {
	Scanner sc=new Scanner(System.in);
	
	public Customer getCustomerDetails()
	{
		Customer customer=new Customer();
		customer.setCustomerID(Utility.generateNumber());
		customer.setFirstName(Utility.promptFirstName());
		customer.setLastName(Utility.promptLastName());
		customer.setEmailID(Utility.promptemailID());
		customer.setMobileNo(Utility.promptMobileNo());
		customer.setDateofBirth(Utility.promptDOB());
		customer.setAddress(getAddressDetails());
		return customer;
	}

	private Address getAddressDetails() {
		Address address=new Address();
		address.setAddressLine1(Utility.promptaddress1());
		address.setAddressLine2(Utility.promptaddress2());
		address.setCity(Utility.promptcity());
		address.setState(Utility.promptstate());
		address.setPincode(Utility.promptpincode());
		return null;
		
		
	}
	
	
	
}
