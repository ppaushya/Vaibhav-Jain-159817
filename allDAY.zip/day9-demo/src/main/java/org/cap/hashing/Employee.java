package org.cap.hashing;

import java.time.LocalDate;

public class Employee implements Comparable<Employee>{
	private int empID;
	private String empName;
	private LocalDate empjoiningDate;
	
	public Employee()
	{
		
	}
	
	
	
	
     

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empID;
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		result = prime * result + ((empjoiningDate == null) ? 0 : empjoiningDate.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (empID != other.empID)
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (empjoiningDate == null) {
			if (other.empjoiningDate != null)
				return false;
		} else if (!empjoiningDate.equals(other.empjoiningDate))
			return false;
		return true;
	}



	public Employee(int empID, String empName, LocalDate empjoiningDate) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.empjoiningDate = empjoiningDate;
	}
     
	

	public int getEmpID() {
		return empID;
	}





	public void setEmpID(int empID) {
		this.empID = empID;
	}





	public String getEmpName() {
		return empName;
	}





	public void setEmpName(String empName) {
		this.empName = empName;
	}





	public LocalDate getEmpjoiningDate() {
		return empjoiningDate;
	}





	public void setEmpjoiningDate(LocalDate empjoiningDate) {
		this.empjoiningDate = empjoiningDate;
	}
    




	@Override
	public int compareTo(Employee o) {
		
		if(this.getEmpID()>o.getEmpID())
			return 1;
		else if(this.getEmpID()<o.getEmpID())
			return -1;
		else 
			return 0;
		}
		






	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName + ", empjoiningDate=" + empjoiningDate + "]";
	}


	

}
