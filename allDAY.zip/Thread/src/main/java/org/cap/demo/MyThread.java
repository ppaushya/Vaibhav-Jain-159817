package org.cap.demo;

public class MyThread  extends Thread{
	
	

	

	public MyThread() {
		// TODO Auto-generated constructor stub
	}

	public MyThread(ThreadDemo runn) {
            
	}

	@Override
	public void run()
	{
		System.out.print(getName()+"---->"+"Thread Started...........\n");
		
	}
}
