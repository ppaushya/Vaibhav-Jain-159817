package org.cap.date;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		regularclassdemo outer=new regularclassdemo();
		regularclassdemo.Innerclass inner=new regularclassdemo().new  Innerclass();

	}

}
