
public class vararg {

	 public void details(int...arr)
	 {
		 for( int value: arr)
			 System.out.println(value);
	 }
	public static void main(String[] args) {
		int[] num= {1,2,3,4};
		vararg obj=new vararg();
		obj.details(num);

	}

}
