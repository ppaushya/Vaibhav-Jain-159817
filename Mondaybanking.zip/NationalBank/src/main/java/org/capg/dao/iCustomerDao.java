package org.capg.dao;

import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Customer;

public interface iCustomerDao {
	public List<Customer> getAllCustomers();
	public void CreateCustomer(Customer customer);
//	public void setAccountDetails(Set<Account> account);
	public Customer ifFound(int customerID);
	public void addAccount(Customer customer,Account account);
    public Account ifaccountFound(Customer customer,int accountNo);

}
