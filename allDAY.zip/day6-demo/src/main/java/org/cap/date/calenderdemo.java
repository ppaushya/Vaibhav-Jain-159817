package org.cap.date;
import java.util.*;

public class calenderdemo {

	public static void main(String[] args) {
	 Calender calen= Calender.getInstance();
	 calen.add(calen.YEARS,3);
	 System.out.println(calen);

	}

}
