package org.cap.capgemini.service;

import java.util.List;

import org.cap.capgemini.dao.ICustomerDao;
import org.cap.capgemini.model.Register;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




@Service("customerService")
public class CustomerServiceImpl implements ICustomerService {
    
	@Autowired
	private ICustomerDao customerDao;
	
	@Override
	public List<Register> getAllRegistration() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomers();
	}

	@Override
	public void updateRegistration(Register register) {
		customerDao.updateCustomer(register);
		
	}

	@Override
	public boolean registerCustomer(Register register) {
		
		return  customerDao.createCustomer(register);
	}

	@Override
	public void deleteRegistration(Integer customerId) {
		customerDao.deleteCustomer(customerId);
		
	}

	@Override
	public Register findRegistration(Integer customerId) {
	
		return customerDao.findCustomer(customerId);
	}

	@Override
	public boolean isValidLogin(Register rPojo) {
		
		return customerDao.isValidLogin(rPojo);
	}
	

}
