package org.cap.view;

import java.util.Scanner;

import org.cap.model.Registration;

public class UserInteraction {
	
	
	Scanner sc=new Scanner(System.in);
	public final double regFees=500;
	
	public Registration createCustomer()
	{
		Registration reg=new Registration();
		reg.setCustomerName(promptcustomerName());
		reg.setMobileNo(promptmobileNo());
		reg.setRegistrationFees(promptregistrationfees());
		int age1=reg.setAge(promptage());
		reg.setActualregistrationFees(promptactualregistrationFees(age1));
		return reg;
	}


	public double promptactualregistrationFees(int age1) {
		double a = 0;
		System.out.print("Actual Registration Fee to be Paid is: Rs.");
		if(age1>0 && age1<18) 
		   a=regFees;
		else if(age1>=18 && age1<25)
		  a=(regFees+regFees*0.1);
		else if(age1>=25 && age1<50)
		  a= (regFees+regFees*0.2);
		else if(age1>=50)
		  a= (regFees+regFees*0.3);
		System.out.print(a);
		return a;
		
	}


	public String promptcustomerName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter Customer Name:");
			fname=sc.next();
			flag=fname.matches("[a-zA-Z]{3,}");
			if(!flag)
				System.out.println("Please enter Valid FirstName!");
		}while(!flag);
		
		return fname;
	}
	public String promptmobileNo() {
		boolean flag=false;
		String mobile;
		do {
			System.out.println("Enter Mobile Number:");
			mobile=sc.next();
			flag=mobile.matches("[789]{1}[0-9]{9}");
			if(!flag)
				System.out.println("Please enter Valid Mobile Number!");
		}while(!flag);
		
		return mobile;
	}
	public double promptregistrationfees()
	{
	   System.out.println("Initial Registration Fees is:Rs."+regFees);
	   return regFees;
	   
	}
	
	public int promptage()
	{
		
		System.out.println("Enter the Customer Age:");
		int age1=sc.nextInt();
		return age1;
	}
	
	
	

}
