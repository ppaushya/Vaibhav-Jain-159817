package InterfacePractice;

public interface Color {

}
