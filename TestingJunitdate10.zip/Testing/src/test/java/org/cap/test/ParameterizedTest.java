package org.cap.test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.cap.demo.Calculate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterizedTest {
	Calculate cal=new Calculate();
	private int[] input;
	private int output;
	public ParameterizedTest(int[] input1, int output) {
		super();
		this.input = input;
		this.output = output;
	}
	
	@Parameters
	public static List<Object[]> getParameters()
	{
		return Arrays.asList(new Object[][] {
			{new int[] {1,2,3,4},10},
			{new int[] {10,2,3,4},20},
			{new int[] {10,2,3,40},55},
			{new int[] {100,2,3,40},145}
		});
	}
	
	@Test
	public void test()
	{
		assertEquals(output,cal.addArray(input));
	}
	
	
	

	

}
