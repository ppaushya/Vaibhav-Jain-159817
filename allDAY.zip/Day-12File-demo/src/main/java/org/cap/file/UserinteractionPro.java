package org.cap.file;

import java.util.Scanner;

public class UserinteractionPro {
Scanner sc=new Scanner(System.in);
	
		
	
	public Product getProductDetails() {
		 System.out.println("Enter ProductID:");
	        int id=sc.nextInt();
	        System.out.println("Enter ProductName:");
	        String id1=sc.next();
	        System.out.println("Enter Quantity:");
	        int id2=sc.nextInt();
	        System.out.println("Enter Amount:");
	        double id3=sc.nextDouble();
	        
	        
		return null;
	}

}
