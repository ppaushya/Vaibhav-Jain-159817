
public class Salariedworker extends Classworker {

	int rate;
	
	public  Salariedworker(String name, int rate, int hour) {
		super(name, empno);
		this.rate = rate;
		this.hour = hour;
	}



	int hour=40;
	public void comPay()
	{
	System.out.println("Salary : "+rate*hour);
	}
	
	
	public static void main(String args[])
	 {
	Dailyworker d=new Dailyworker("Arjun",254,75);
	Salariedworker s=new Salariedworker(666,"Unni",100);
	d.comPay(45);
	s.comPay();
	}
}