package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;

public class AccountDaoImpl implements IAccountDao{
	
private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	
	@Override
	public Account createAccount(Account account) {
		
		String sql="insert into account(accountType,openingDate,openingBalance,description,customerId) values(?,?,?,?,?);";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			pst.setString(1, account.getAccountType().toString());
			pst.setDate(2,Date.valueOf(account.getOpeningDate()));
            pst.setDouble(3, account.getOpeningBalance());
            pst.setString(4, account.getDescription());
            pst.setInt(5, account.getCustomer().getCustomerId());

            int count=pst.executeUpdate();
            if(count>0)
            {
            	return account;
            }
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}


	@Override
	public List<Account> getAllAccounts(Customer customer) {
		List<Account> accounts=new ArrayList<>();
		String sql="select * from account where customerId=?;";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			pst.setInt(1, customer.getCustomerId());
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Account account=new Account();
				account.setAccountNumber(rs.getInt(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				account.setOpeningDate(rs.getDate(3).toLocalDate());
				account.setOpeningBalance(rs.getDouble(4));
				account.setDescription(rs.getString(5));
				accounts.add(account);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(accounts.isEmpty()) 
		{
		return null;
		}
		else
			return accounts;
	}
	
	@Override
	public Account getAccount(int accountNo) {
		String sql="select * from account where accountNumber=?;";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			pst.setInt(1, accountNo);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Account account=new Account();
				account.setAccountNumber(rs.getInt(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				account.setOpeningDate(rs.getDate(3).toLocalDate());
				account.setOpeningBalance(rs.getDouble(4));
				account.setDescription(rs.getString(5));
				return account;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}

	@Override
	public List<Account> getAlltoAccounts(Customer customer) {
			List<Account> accounts=new ArrayList<>();
			String sql="select * from account where customerId<>?;";
			try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
				pst.setInt(1, customer.getCustomerId());
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					Account account=new Account();
					account.setAccountNumber(rs.getInt(1));
					account.setAccountType(AccountType.valueOf(rs.getString(2)));
					account.setOpeningDate(rs.getDate(3).toLocalDate());
					account.setOpeningBalance(rs.getDouble(4));
					account.setDescription(rs.getString(5));
					accounts.add(account);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(accounts.isEmpty()) 
			{
			return null;
			}
			else
				return accounts;
		}
	

	public List<Account> getAccountsForCustomer(int custId)	{
		List<Account> accounts=new ArrayList<>(); 
		
		
		String sql="select * from account where customerId="+custId+";";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				Account account=new Account();
				account.setAccountNumber(rs.getInt(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				account.setOpeningBalance(rs.getDouble(4));
				accounts.add(account);
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accounts;
	}
		
	}
	
	

 
