import java.util.Scanner;

public class Matrix2D {
 
	int[][] arr;
	 Scanner sc=new Scanner(System.in);
	public void getValue(int n,int m)
	{
		int i,j=0;
		if(n==m)
		{
		arr=new int[n][n];
		System.out.println("Enter the values: ");
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				System.out.print(arr[i][j]+ "\t");
			}
			System.out.println();
		}
		
	}
		else 
			System.out.println("It's not a Square matrix");
		System.out.println("Lower Traingle");
		for(i=0;i<n;i++)
		{
			for(j=0;j<=i;j++)
			{

				System.out.print(arr[i][j]+ "\t");
			}
			System.out.println();
		}
		
		System.out.println("transpose Matrix");
		for(i = 0; i <n; i++)
    	{
      	    for(j = 0; j < n; j++)
            {
                System.out.print(arr[j][i]+" ");
            }
            System.out.println(" ");
        }
	  	
	}
	
	public static void main(String[] args) {
	   Matrix2D obj= new Matrix2D();
	   obj.getValue(3,3);
	}

}
