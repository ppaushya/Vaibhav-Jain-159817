package org.cap.hashing;

public class Address {
	private String addline1;
	private String addline2;
	private String City;
	private String State;
	
	public Address()
	{
		
	}

	public Address(String addline1, String addline2, String city, String state) {
		super();
		this.addline1 = addline1;
		this.addline2 = addline2;
		this.City = city;
		this.State = state;
	}

	@Override
	public String toString() {
		return "Address [addline1=" + addline1 + ", addline2=" + addline2 + ", City=" + City + ", State=" + State + "]";
	}
	
	

}
