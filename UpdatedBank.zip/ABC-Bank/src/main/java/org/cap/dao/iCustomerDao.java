package org.cap.dao;

import java.util.List;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface iCustomerDao {
	public List<Customer> getAllCustomers();
	public void CreateCustomer(Customer customer);
//	public void setAccountDetails(Set<Account> account);
	public Customer ifFound(int customerID);
	public void addAccount(Customer customer,Account account);


}