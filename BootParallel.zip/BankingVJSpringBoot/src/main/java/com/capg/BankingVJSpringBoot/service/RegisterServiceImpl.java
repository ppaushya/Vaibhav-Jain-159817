package com.capg.BankingVJSpringBoot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.BankingVJSpringBoot.dao.IRegisterDao;
import com.capg.BankingVJSpringBoot.model.Customer;

@Service("registerService")
public class RegisterServiceImpl implements IRegisterService{

	@Autowired
	private IRegisterDao registerDao;
	
	
	@Override
	public void registerCustomer(Customer customer) {
		registerDao.save(customer);
		
	}

}
