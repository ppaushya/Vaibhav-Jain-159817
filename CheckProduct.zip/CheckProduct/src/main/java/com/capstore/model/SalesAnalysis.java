package com.capstore.model;

public class SalesAnalysis {

	private String productCategory;
	private int merchantId;
	private long productQuantity;
	private long productSales;
	private double salesPercent;
	public SalesAnalysis(String productCategory, int merchantId, long productQuantity, long productSales,
			double salesPercent) {
		super();
		this.productCategory = productCategory;
		this.merchantId = merchantId;
		this.productQuantity = productQuantity;
		this.productSales = productSales;
		this.salesPercent = salesPercent;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public long getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(long productQuantity) {
		this.productQuantity = productQuantity;
	}
	public long getProductSales() {
		return productSales;
	}
	public void setProductSales(long productSales) {
		this.productSales = productSales;
	}
	public double getSalesPercent() {
		return salesPercent;
	}
	public void setSalesPercent(double salesPercent) {
		this.salesPercent = salesPercent;
	}
	@Override
	public String toString() {
		return "SalesAnalysis [productCategory=" + productCategory + ", merchantId=" + merchantId + ", productQuantity="
				+ productQuantity + ", productSales=" + productSales + ", salesPercent=" + salesPercent + "]";
	}
	
	
	
}
