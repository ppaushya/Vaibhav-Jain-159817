package org.cap.de;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class Servlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Servlet started");
	}

	
	public void destroy() {
		System.out.println("Servlet Destroyed");
	}

	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("Service called");
		PrintWriter out=response.getWriter();
		out.print("<h1>Heyy!!</h1>");
	}

}
