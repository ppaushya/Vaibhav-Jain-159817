import { Component } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: 'pm-login',
  templateUrl:'./login.component.html',
  styleUrls:['./login.component.css']
})
export class LoginComponent{
    constructor(private _router:Router) {
        
       }
    onSubmit():void{
        this._router.navigate(['/MainPage']);
      }

    onSubmitted():void{
        this._router.navigate(['/Registration']);
      }
}