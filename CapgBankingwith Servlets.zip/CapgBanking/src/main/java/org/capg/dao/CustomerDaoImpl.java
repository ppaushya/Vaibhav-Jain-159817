package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.capg.model.Address;
import org.capg.model.Customer;

public class CustomerDaoImpl implements ICustomerDao{
	
	private static List<Customer> customers=dummyDb();
	
	private static List<Customer> dummyDb(){
		List<Customer> customers=new ArrayList<>();
		
		Address address=new Address("23,west Car St", "2nd St", "Chennai", "TN", "234442");
		customers.add(new Customer(123,"Jack","Thomson", LocalDate.of(1991, 01, 23),
				"jack@gmail.com","8890912345",address));
		
		Address address1=new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", "657657");
		customers.add(new Customer(1090,"Tom","Jerry", LocalDate.of(1987, 12, 23),
				"tom@gmail.com","9090912345",address1));
		
		return customers;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		String sql="select * from customer where emailId=? and customerPwd=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setString(1, customer.getFirstName());
			pst.setString(2, customer.getLastName());
			pst.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
			pst.setString(4,customer.getEmailId());
			pst.setString(5,customer.getMobile());
			pst.setString(6,customer.getuserPassword());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "admin");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}

}
