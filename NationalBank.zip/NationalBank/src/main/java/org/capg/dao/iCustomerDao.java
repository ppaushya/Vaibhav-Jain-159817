package org.capg.dao;

public interface iCustomerDao {
	public List<Customer> getAllCustomers

}
