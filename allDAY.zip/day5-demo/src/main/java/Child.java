
public class Child extends parent {

   int num=900;
   
	public Child(int num,int num1) {
	super(num,num1);
	this.num = num1;
}
	public void show()
	{
		
		System.out.println(num);
		super.show();
	}
	public static void main(String[] args) {
		Child chi=new Child(100,500);
		chi.show();
		

	}

}
