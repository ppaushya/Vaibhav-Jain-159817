package org.capg.util;

import java.time.LocalDate;
import java.util.Scanner;

import org.capg.model.AccountType;

public class Utility {
	static Scanner sc=new Scanner(System.in);
	
	public static int generateNumber()
	{
		return (int)(Math.random()*1000)/100;
		
	}
	public static String promptFirstName()
	{
		boolean flag=false;
		String fname;
		do
		{
			System.out.println("Enter First Name: ");
			fname=sc.next();
			flag=fname.matches("[a-zA-Z]{3,}");
					if(!flag)
					{
						System.out.println("Please Enter Valid First Name:");
					}
		}while(!flag);
		return fname;
	}


	public static String promptLastName()
	{
		boolean flag=false;
		String lname;
		do
		{
			System.out.println("Enter Last Name: ");
			lname=sc.next();
			flag=lname.matches("[a-zA-Z]{3,}");
					if(!flag)
					{
						System.out.println("Please Enter Valid Last Name:");
					}
		}while(!flag);
		return lname;
	}

    public static String promptemailID()
    {
    	boolean flag=false;
    	String email;
    	do {
    		System.out.println("Enter Email:");
    		email=sc.next();
    		flag=email.matches("[a-z0-9_-]{1,}@[a-z]{1,}.[a-z]{1,}");
    		if(!flag)
    		{
    			System.out.println("Please Enter Valid Email: ");
    		}
    		
    	}while(!flag);
    	return email;
    }
    
    public static LocalDate promptDOB()
    {
       String dob;
        Integer date,month,year;
        boolean flag=false;
        do {
            System.out.println("Enter Date of Birth(dd-mm-yyyy) :");
            dob=sc.next();
            date=Integer.parseInt(dob.substring(0, 2));
            month=Integer.parseInt(dob.substring(3, 5));
            year=Integer.parseInt(dob.substring(6, 9));
            if(dob.charAt(2)!='-'||dob.charAt(5)!='-')
            {
            	System.out.println("Enter the valid Date of Birth(dd-mm-yyyy): ");
            	flag=false;
            }
            else flag=true;
        }while(!flag);
      
	return LocalDate.of(year, month, date);
       
       
    }
    public static String promptMobileNo()
    {
    	boolean flag=false;
    	String mobile;
    	do {
    		System.out.println("Enter Mobile Number:");
    		mobile=sc.next();
    		flag=mobile.matches("[0-9]{10}");
    		if(!flag)
    		{
    			System.out.println("Please Enter Valid Mobile Number: ");
    		}
    		
    	}while(!flag);
    	return mobile;
    }
    
     public static String promptpincode()
    {
    	boolean flag=false;
    	String pin;
    	do {
    		System.out.println("Enter Pincode:");
    		pin=sc.next();
    		flag=pin.matches("[0-9]{6}");
    		if(!flag)
    		{
    			System.out.println("Please Enter Valid Pincode: ");
    		}
    		
    	}while(!flag);
    	return pin;
    }
    
     public static String promptaddress1()
     {
    	 System.out.println("Enter the AddressLine1: ");
    	 String line1;
    	 line1=sc.next();
    	 //System.out.println(line1);
    	 return line1;
     }
     public static String promptaddress2()
     {
    	 System.out.println("Enter the AddressLine2: ");
    	 String line2;
    	 line2=sc.next();
    	 //System.out.println(line2);
    	 return line2;
     }
     public static String promptcity()
     {
    	 System.out.println("Enter the City: ");
    	 String city;
    	 city=sc.next();
    	 //System.out.println(city);
    	 return city;
     }
     public static String promptstate()
     {
    	 System.out.println("Enter the State: ");
    	 String state;
    	 state=sc.next();
    	 //System.out.println(state);
    	 return state;
     }
     
 	
 	public static long generateAccountNumber()
 	{
 		return (long)(Math.random()*10000)/10;
 		
 	}

	public static void printAccountType() {
		System.out.println("-------------------------------------------");
		System.out.println("Enter Account Type: ");
		
		AccountType[] types=AccountType.values();
		int count=0;
		for(AccountType type:types)
			System.out.println(++count + "." + type);
		
	}

	public static AccountType assignAccountType(int value) {
		switch(value) {
		case 1:
			return AccountType.SAVINGS;
		case 2:
			return AccountType.CURRENT;
		case 3:
			return AccountType.RD;
		case 4:
			return AccountType.FD;
		default:
			System.out.println("Invalid Account Type");
			System.exit(0);
		}
		return null;
		
	}
	
   public static LocalDate promptopeningDate() {
	   
	   System.out.println("Account opening Date is :");
         System.out.println(LocalDate.now());
		return null; 

   }
    
   public static double promptopeningBalance() {
	   System.out.println("Enter Opening Balance:");
	   double bal=sc.nextDouble();
	   return bal;
   }
   public static String promptDescription()
   {
	   System.out.println("Enter Description:");
		String description=sc.next();
		return description;
   }
   
   public static long generateTransactionID()
	{
		return (long)(Math.random()*1000000)/100;
		
	}
   
   
  
    
}
