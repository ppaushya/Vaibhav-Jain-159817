package org.cap.boot;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.employee;

public class Mainclass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entitymanager=emf.createEntityManager();
		
		EntityTransaction transactions=entitymanager.getTransaction();
		
		transactions.begin();
		
		employee emp=new employee("Ishan","Gupta",50000);
		employee emp1=new employee("Roshni","Gupta",50000);
		 emp.setDOJ(new Date());
		emp.setUserPass("rohan");
		
		emp1.setDOJ(new Date());
		emp1.setUserPass("roshni");
		entitymanager.persist(emp);
		entitymanager.persist(emp1);
		
		transactions.commit();
		
		
		

	}

}
