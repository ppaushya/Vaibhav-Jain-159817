package org.cap.demo;

public class Customer {
	private int customerID;
	private String customerName;
	private Address address;
	private Account account;
	
	public Customer()
	{
		
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Customer(int customerID, String customerName, Address address, Account account) {
		super();
		this.customerID = customerID;
		this.customerName = customerName;
		this.address = address;
		this.account = account;
	}
	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customerName=" + customerName + ", address=" + address
				+ ", account=" + account + "]";
	}
	
	

}
