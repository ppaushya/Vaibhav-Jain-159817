package com.thebank.service;

import com.thebank.model.Account;
import com.thebank.model.Customer;
import com.thebank.model.User;

public interface IUserService {

	//check if userId exists in db

	public User userExists(long userId);

	public Customer getCustomer(long customerId);//Fetch complete details including account set using getCustomer function

	public void changePassword(String pwd);

	public Account ifAccountFound(Customer customer, long fromAccountId);

	public Account ifAccountFoundTo(long toAccountId);//search from account db
}
