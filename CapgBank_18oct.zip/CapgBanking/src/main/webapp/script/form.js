function validateForm(){
	console.log("validateForm");
	var flag=false;
	var firstName = f2.firstName.value;
	var lastName = f2.lastName.value;
	var dateOfbirth = f2.dateOfbirth.value;
	var email = f2.email.value;
	var mobile = f2.mobile.value;
	var addressline1 = f2.addressline1.value;
	var addressline2 = f2.addressline2.value;
	var city = f2.city.value;
	var state = f2.state.value;
	var pincode = f2.pincode.value;
	var userPass = f2.userPass.value;
	var confirmCustPwd = f2.confirmCustPwd.value;
	
	var firstNameErrMsg = document.getElementById("firstNameErrMsg");
	var lastNameErrMsg = document.getElementById("lastNameErrMsg");
	var DoBErrMsg = document.getElementById("DoBErrMsg");
	var EmailErrMsg = document.getElementById("EmailErrMsg");
	var MobileErrMsg = document.getElementById("MobileErrMsg");
	var AddressErrMsg = document.getElementById("AddressErrMsg");
	var Address1ErrMsg = document.getElementById("Address1ErrMsg");
	var CityErrMsg = document.getElementById("CityErrMsg");
	var StateErrMsg = document.getElementById("StateErrMsg");
	var PincodeErrMsg = document.getElementById("PincodeErrMsg");
	var PassErrMsg = document.getElementById("PassErrMsg");
	var ConPassErrMsg = document.getElementById("ConPassErrMsg");

	
	
}
	
	
	