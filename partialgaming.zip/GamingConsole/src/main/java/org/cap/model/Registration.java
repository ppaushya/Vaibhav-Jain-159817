package org.cap.model;

public class Registration {
	private int registrationID;
	private String customerName;
	private String mobileNo;
	private double registrationFees;
	private int age;
	private double actualregistrationFees;
	
	public Registration() {
		
	}
	
	

	public Registration(int registrationID, String customerName, String mobileNo, double registrationFees, int age,
			double actualregistrationFees) {
		super();
		this.registrationID = registrationID;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.registrationFees = registrationFees;
		this.age = age;
		this.actualregistrationFees = actualregistrationFees;
	}



	public int getRegistrationID() {
		return registrationID;
	}

	public void setRegistrationID(int registrationID) {
		this.registrationID = registrationID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public double getRegistrationFees() {
		return registrationFees;
	}

	public void setRegistrationFees(double registrationFees) {
		this.registrationFees = registrationFees;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getActualregistrationFees() {
		return actualregistrationFees;
	}

	public void setActualregistrationFees(double actualregistrationFees) {
		this.actualregistrationFees = actualregistrationFees;
	}



	@Override
	public String toString() {
		return "Registration [registrationID=" + registrationID + ", customerName=" + customerName + ", mobileNo="
				+ mobileNo + ", registrationFees=" + registrationFees + ", age=" + age + ", actualregistrationFees="
				+ actualregistrationFees + "]";
	}
	

	
}
