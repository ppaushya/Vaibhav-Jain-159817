package com.capg.BankingVJSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingVjSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingVjSpringBootApplication.class, args);
	}
}
