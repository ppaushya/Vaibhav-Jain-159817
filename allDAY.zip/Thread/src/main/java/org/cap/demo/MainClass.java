package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
        ThreadDemo runn=new ThreadDemo();   
		Thread t1=new Thread(runn);
		
           Thread t2=new Thread(runn,"Thread2");
           
           Thread t3=new Thread(runn,"Thread3");
           t1.setPriority(Thread.MAX_PRIORITY);
           t3.start();
           t2.start();
           try {
        	   t1.join(100);
           }catch(InterruptedException e)
           {
        	   e.printStackTrace();
           }
           try {
        	   t3.join(100);
           }catch(InterruptedException e)
           {
        	   e.printStackTrace();
           }
          
           try {
        	   t2.join(100);
           }catch(InterruptedException e)
           {
        	   e.printStackTrace();
           }
	}

}
