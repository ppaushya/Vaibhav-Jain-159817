package org.cap.date;

public class regularclassdemo {

	public static void main(String[] args) {
		int num;
		String name;
		class Innerclass{
			String address;
			public void show() 
			{
				System.out.println(num);
				System.out.println(name);
				System.out.println(address);

			}
		}
		public print()
	    {
			Innerclass obj=new Innerclass();
			System.out.println(obj.show());
		}		// TODO Auto-generated method stub

	}

}
