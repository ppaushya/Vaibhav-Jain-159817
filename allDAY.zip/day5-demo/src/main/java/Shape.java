
public abstract class Shape {
           int width;
           int height;
           
           public void info() {
        	   System.out.println("Shape info");}
        	   
        	   public abstract void draw();
           
	public static void main(String[] args) {
		
		Circle obj=new Circle();
		double area=obj.CalculateArea();
		System.out.println("Area is "+ area);
		obj.draw();

	}

}
