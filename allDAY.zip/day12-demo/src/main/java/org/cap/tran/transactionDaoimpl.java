package org.cap.tran;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class transactionDaoimpl {
	
	
	public void performTransaction()
	{
		Connection conn=null;
		try {
			conn=getDbConnection();
			conn.setAutoCommit(false);
			Employee emp=new Employee();
			String sql="insert into employee values(?,?,?,?,?)";
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, emp.getEmpID());
			pst.setString(2, emp.getFirstName());
			pst.setString(3, emp.getLastname());
			pst.setDouble(4, emp.getSalary());
			pst.setDate(5, java.sql.Date.valueOf(emp.getEmpdoj()));
			int count=pst.executeUpdate();
			
			
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

}
