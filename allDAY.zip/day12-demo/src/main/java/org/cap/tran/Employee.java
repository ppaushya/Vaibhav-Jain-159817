package org.cap.tran;

import java.sql.Date;
import java.time.LocalDate;

public class Employee {
	private int empID;
	private String FirstName;
	private String Lastname;
	private double salary;
	private LocalDate empdoj;
	
	
	public Employee()
	{
		
	}
	public Employee(int empID, String firstName, String lastname, double salary, LocalDate empdoj) {
		super();
		this.empID = empID;
		this.FirstName = firstName;
		this.Lastname = lastname;
		this.salary = salary;
		this.empdoj = empdoj;
	}
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getEmpdoj() {
		return empdoj;
	}
	public void setEmpdoj(LocalDate empdoj) {
		this.empdoj = empdoj;
	}
	
	
	
	

}
