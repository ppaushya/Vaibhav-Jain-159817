package org.cap.demo;

import java.util.Scanner;

public class student {
	String name;
	int marks1,marks2,marks3;
	public void getStudent()
	{
		 Scanner scanner=new Scanner(System.in);
		 System.out.println("Enter Name:" );
		 name=scanner.next();
		 System.out.println("Enter Marks1:" );
		 marks1=scanner.nextInt();
		 System.out.println("Enter Marks2:" );
		 marks2=scanner.nextInt();
		 System.out.println("Enter Marks3:" );
		 marks3=scanner.nextInt();
		 scanner.close();
	}
	public int findScore()
	{
		int score=marks1+marks2+marks3;
		return score;
	}
	public int findAverage()
	{
		int average=findScore();
		return average/3;
	}
	public void printStudent()
	{
		int x=findScore();
		int y=findAverage();
		System.out.println("Student Details: \n Name:" + name +"\n Total Score: "+x+ "\n Average: " +y);
		
	}
	
	public static void main(String[] args) {
		student obj=new student();
		obj.getStudent();
		obj.printStudent();
		// TODO Auto-generated method stub

	}

}
