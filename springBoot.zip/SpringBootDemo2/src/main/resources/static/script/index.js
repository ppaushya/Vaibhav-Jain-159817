function validate(){
	
	  
	
			var flag=false;
			var uname=f1.userName.value;
			var uPass=f1.userPassword.value;
			
			if(uname==""||uname==null){
				document.getElementById('userErrMsg').innerHTML="*Please enter UserName.";
				flag=false;
			}else if(uPass==""||uPass==null){
				document.getElementById('pwdErrMsg').innerHTML="*Please enter Password.";
				document.getElementById('userErrMsg').innerHTML="";
				flag=false;
			}else{
				document.getElementById('pwdErrMsg').innerHTML="";
				document.getElementById('userErrMsg').innerHTML="";
				flag=true;
			}
			
			return flag;
			
		} 
		 
