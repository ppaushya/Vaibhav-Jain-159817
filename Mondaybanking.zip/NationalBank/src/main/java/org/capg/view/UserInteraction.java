package org.capg.view;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.util.Utility;

public class UserInteraction {
	 Scanner sc=new Scanner(System.in);
	 ICustomerService customerservice=new CustomerServiceImpl(); 
	 
	 public Transaction doingTransaction(Customer customer)
	 {
		 System.out.println("Choose your option:");
		 System.out.println("1.Deposit");
		 System.out.println("2.Withdrawal");
		 System.out.println("3.Funds Transfer");
		 int transactionType=sc.nextInt();
		 Account account=new Account();
		 Transaction transaction=new Transaction();
		 int accountNo=0;
		
		 switch(transactionType)
		 {
		 case 1:
			 System.out.println("Choose Account to Deposit:");
			 printAccounts(customer.getAccounts());
			 accountNo=sc.nextInt();
			 account=customerservice.ifaccountFound(customer,accountNo);
			 if(account==null)
			 {
				 System.out.println("Account Number Does Exist for particular Customer ID!!");
				 break;
			 }
			 transaction.setTransactionType("Debit");
			 System.out.println("Enter the amount to be Deposited?");
			 double amount=sc.nextDouble();
			 transaction.setToAccount(account);
			 transaction.setFromAccount(account);
			 System.out.println("Amount Deposited Successfully!!");
			 break;
		 case 2:
			 System.out.println("Choose Account to Withdrawal");
			 printAccounts(customer.getAccounts());
			 accountNo=sc.nextInt();
			 account=customerservice.ifaccountFound(customer, accountNo);
			 if(account==null)
			 {
				 System.out.println("Account number does not exist for this particular customer ID!!");
				 break;
			 }
			 transaction.setTransactionType("Withdrawal");
			 System.out.println("Enter Amount to be Debited:");
			 amount=sc.nextDouble();
			 while(amount>customerservice.getCurrentBalance)
			 
			 
			 
			 
		 }
		 
		
		 
		 
		 
		 
	   return transaction;
		 
	 }
	
	public Customer getCustomerDetails()
	{
		Customer customer=new Customer();
		customer.setCustomerID(Utility.generateNumber());
		customer.setFirstName(Utility.promptFirstName());
		customer.setLastName(Utility.promptLastName());
		customer.setEmailID(Utility.promptemailID());
		customer.setMobileNo(Utility.promptMobileNo());
		customer.setDateofBirth(Utility.promptDOB());
		customer.setAddress(getAddressDetails());
		
		return customer;
	}

	public Account getAccountDetails() {
		
		Account account=new Account();
		account.setAccountNumber(Utility.generateAccountNumber());
		Utility.printAccountType();
		System.out.println("Choose Account Type[1,2,3,4]:");
		int accountTypeNo=sc.nextInt();
		account.setAccountType(Utility.assignAccountType(accountTypeNo));
		account.setOpeningDate(Utility.promptopeningDate());
		account.setOpeningBalance(Utility.promptopeningBalance());
		account.setDescription(Utility.promptDescription());
		return account;
	}

	public Address getAddressDetails() {
		Address address=new Address();
		address.setAddressLine1(Utility.promptaddress1());
		address.setAddressLine2(Utility.promptaddress2());
		address.setCity(Utility.promptcity());
		address.setState(Utility.promptstate());
		address.setPincode(Utility.promptpincode());
		return address;
		
		
	}
	
	
	public static void printError(String message)
	{
		System.out.println(message);
	}

	public static void printCustomers(List<Customer> customers) {
		  System.out.println("CustomerID\tCustomerName\t\tEmailID\t\t\tMobileNo. ");
		  System.out.println("------------------------------------------------------------------------------------------------------");
		  for(Customer customer:customers) {
			  System.out.println(customer.getCustomerID()+"\t\t"+customer.getFirstName()+" "+customer.getLastName()+"\t\t"+customer.getEmailID()+"\t\t"+customer.getMobileNo());
		  }
		
	}
	
	public static void printcustomerAccounts(List<Customer> customers)
	{
		 System.out.println("CustomerID\tCustomerName\t\tEmailID\t\t\tMobileNo. ");
		 System.out.println("------------------------------------------------------------------------------------------------------");
		 for(Customer customer:customers)
		 {
			 System.out.println(customer.getCustomerID()+"\t\t"+customer.getFirstName()+" "+customer.getLastName()+"\t\t"+customer.getEmailID()+"\t\t"+customer.getMobileNo()+"\t\t"+customer.getAccounts()); 
		 }
		 
     }
	
	public void printAccounts(Set<Account> accounts) {
		System.out.println("AccountNo\tAccount Type\tAccount OpeningBalance\t Account OpeningDate\tDescription... ");
		System.out.println("------------------------------------------------------------------------------------------------------");
		 for(Account account:accounts)
		 {
			 System.out.println(account.getAccountNumber()+"\t\t"+account.getAccountType()+"\t\t"+account.getOpeningBalance()+"\t\t"+account.getOpeningDate()+"\t\t"+account.getDescription()); 
		 }
	}
	
	
}
