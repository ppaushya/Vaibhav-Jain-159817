import { Injectable } from '@angular/core';
import { Product } from '../../models/product';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SortService {

  private _sortUrl='./app/products/products.json';
  constructor(private _http:HttpClient){}

  getProducts():Observable<Product[]>{

      return this._http.get<Product[]>(this._sortUrl)
                  //.do(data=>console.log('All :' + JSON.stringify(data)))
                  //.catch(this.handleError);
  }

  private handleError(err: HttpErrorResponse){
      console.error(err.message);
      return Observable.throw(err.message);
  }


  // private sortUrl="http//localhost:3306/capstore/api/v1/";

  // constructor(private http:HttpClient) { }

  // getAscProducts():Observable<Product[]>{
     
  //   return this.http.get<Product[]>(this.sortUrl);
  // }
  // getDscProducts():Observable<Product[]>{
     
  //   return this.http.get<Product[]>(this.sortUrl);
  // }

  // getMostViewed():Observable<Product>{
  //   return this.http.get<Product>(this.sortUrl);
  // }

  // getInRangeProducts(min,max):Observable<Product[]>{
  //   return this.http.get<Product[]>(this.sortUrl+'/'+min +'/'+ max);
  // }
}
