package org.cap.tran;

public interface transactionDao {
	
	public void performTransaction();

}
