import java.util.Arrays;

public class Customer {



		private int customerId;
		private String name;
		private Address ad=new Address();
		private Account[] ac=new Account[5];
		private String mobileNo;
		private String emailId;
		private int accountCount;
	        Customer()
	        {
	            
	        }
	        Customer(int customerId,String name,String stName,String city,String state,String mobileNo,String emailId)
	        {
	            this.customerId=customerId;
	            this.name=name;
	            ad.setStName(stName);
	            ad.setCity(city);
	            ad.setState(state);
	            this.mobileNo=mobileNo;
	            this.emailId=emailId;
	            
	        }
	        public int getCustomerId()
	        {
	            return customerId;
	        }
	        public String getName()
	        {
	            return name;
	        }
	        public String getAddress()
	        {
	            return ad.getStName()+","+ad.getCity()+","+ad.getState();
	        }
	        public String getMobile()
	        {
	            return mobileNo;
	        }
	         public String getEmail()
	        {
	            return emailId;
	        }
	         public int getAccountCount()
	        {
	            return this.accountCount;
	        }
	         
	         
	         
	         @Override
			public String toString() {
				return "Customer [customerId=" + customerId + ", name=" + name + ", ad=" + ad + ", ac="
						+ Arrays.toString(ac) + ", mobileNo=" + mobileNo + ", emailId=" + emailId + ", accountCount="
						+ accountCount + "]";
			}
			//setters
	        public void setAccount(int accountCount,long accountNo,String accountType,double openingBalance)
	        {
	           ac[accountCount]=new Account();
	           ac[accountCount].setAccountNo(accountNo);
	           ac[accountCount].setAccountType(accountType);
	           ac[accountCount].setOpeningDate();
	           ac[accountCount].setOpeningBalance(openingBalance);
	           ac[accountCount].setCurrentBalance();
	        }
	        public void setAccountCount(int accountCount)
	        {
	            this.accountCount=accountCount;
	        }
	        public void setCurrentBalance(double amount,int index)
	        {
	            ac[index].setCurrentBalance(amount);
	        }
	        
	        //getters
	        public long getAccountNo(int accountCount)
	        {
	            return ac[accountCount].get1AccountNo();
	        }
	        public String getAccountType(int accountCount)
	        {
	            return ac[accountCount].get1AccountType();
	        }
//	        public Instant getOpeningDate(int accountCount)
//	        {
//	            return ac[accountCount].get1OpeningDate();
//	        }
	        public double getOpeningBalance(int accountCount)
	        {
	            return ac[accountCount].get1OpeningBalance();
	        }
	        public double getCurrentBalance(int accountCount)
	        {
	            return ac[accountCount].get1CurrentBalance();
	        }
}
