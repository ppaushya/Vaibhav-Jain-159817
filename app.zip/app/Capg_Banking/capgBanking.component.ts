
import { Component, OnChanges, Input, EventEmitter,Output } from "@angular/core";

@Component({
 
    templateUrl:'./capgBanking.component.html'
}
)
export class CapgBankingComponent {
    msg:string="Hi";
}