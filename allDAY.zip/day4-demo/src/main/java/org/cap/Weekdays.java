package org.cap;

public enum Weekdays {

	 SUN(1),MON(2),TUE(3),WED(4),THUR(5),FRI(6),SAT(7);
	int value;
      Weekdays(int var)      //enum constructor
	{
		 this.value=var;
	}
	
	public int getValue() {
		return this.value;
	}
}
