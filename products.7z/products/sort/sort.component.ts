import { Component, OnInit } from '@angular/core';
import { SortService } from './sort.service';
import { Product } from '../../models/product';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.scss']
})
export class SortComponent implements OnInit {

  _listFilter: string;
  products: Product[] = [];
  range: Range;
  filteredProducts: Product[];
  errorMessage: string;

  constructor(private sortService: SortService) { }

  ngOnInit() {
    this.sortService.getProducts().subscribe(products => {
      this.products = products;
      this.filteredProducts = this.products;

    },
      error => this.errorMessage = <any>error
    );

  }


  get listFilter(): string {
    return this._listFilter
  }
  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredProducts = this.listFilter ? this.performFilter(this.listFilter) : this.products;

  }

  performFilter(filterBy: string): Product[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.products.filter((product: Product) =>
      product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }



  // lowtohigh():void{
  //   this.sortService.getAscProducts().subscribe(Allproducts=>{this.Allproducts=Allproducts});
  // }

  // hightolow():void{
  //   this.sortService.getDscProducts().subscribe(Allproducts=>{this.Allproducts=Allproducts});
  // }

  // mostViewed():void{
  //   this.sortService.getMostViewed().subscribe(product=>{this.product=product});
  // }

  // inRange(min:Range,max:Range):void{
  //   this.sortService.getInRangeProducts(min,max).subscribe(Allproducts=>{this.Allproducts=Allproducts});

  // }


}
