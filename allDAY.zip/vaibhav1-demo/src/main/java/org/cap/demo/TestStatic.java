package org.cap.demo;

public class TestStatic {

	 String name;
	 static int count;
	 final float pi=3.14f;
	 public static void show()
	 {
		 System.out.println("Count:" + count);
		 //System.out.println("Name:" + name);
	 }
	public static void main(String[] args) {
		TestStatic obj=new TestStatic();
		obj.name="Tom";
		obj.count=10;
		System.out.println("Name:" + obj.name);
		System.out.println("Count:" + obj.count);
		obj.show();
		System.out.println("Pi:" + obj.pi);
	}

}
