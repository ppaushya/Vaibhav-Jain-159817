
public class Student {
  private int studenID;
   private String firstname;
  private String lastname;
  private double regFees;
  
  public Student(int studenID, String firstname, String lastname, double regFees) {
	super();
	this.studenID = studenID;
	this.firstname = firstname;
	this.lastname = lastname;
	this.regFees = regFees;
}
public Student()
  {
	  
  }
	public int getStudenID() {
	return studenID;
}


public void setStudenID(int studenID) {
	this.studenID = studenID;
}


public String getFirstname() {
	return firstname;
}


public void setFirstname(String firstname) {
	this.firstname = firstname;
}


public String getLastname() {
	return lastname;
}


public void setLastname(String lastname) {
	this.lastname = lastname;
}


public double getRegFees() {
	return regFees;
}


public void setRegFees(double regFees) {
	this.regFees = regFees;
}

}