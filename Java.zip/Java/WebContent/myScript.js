var myfun=function(){
	for(key in emp){
		console.log(key+'-'+emp[key])
	}
	console.log(empOne);
	console.log("EmpId:"+emp.empId);
	console.log("EmpSalary:"+emp.salary);
	console.log('Hello!Good Evening')
}
var emp={
		empId:1001,
        firstName:'tom',
        lastName:'jerry',
        salary:23000}

var empOne={
		eid:1001,ename:'ABCD'}
        alert("eid" in empOne);
        alert("edep" in empOne);

myfun();

