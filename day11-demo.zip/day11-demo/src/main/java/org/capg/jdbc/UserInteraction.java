package org.capg.jdbc;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class UserInteraction {
	Scanner sc=new Scanner(System.in);
	
	
	public int promptEmployeeID() {
		System.out.println("Enter Employee Id:");
		return sc.nextInt();
	}
	
	public Employee createEmployee()
	{
		Employee emp=new Employee();
		System.out.println("Enter Employee Id:");
		emp.setEmpID(sc.nextInt());
		
		System.out.println("Enter Employee FirstName:");
		emp.setFirstName(sc.next());
		
		System.out.println("Enter Employee LastName:");
		emp.setLastname(sc.next());
		
		System.out.println("Enter Employee Salary:");
		emp.setSalary(sc.nextDouble());
		
		System.out.println("Enter Employee DateOf Joining[yyyy-mm-dd]:");
		String[] date=sc.next().split("-");
		emp.setEmpdoj(LocalDate.of(
				Integer.parseInt(date[0]), 
				Integer.parseInt(date[1]), 
				Integer.parseInt((date[2]))));
		
		return emp;
	}
	
	public void printAllEmployees(List<Employee> employees) {
		System.out.println("EmployeeId\tFirstName\tLastName\tSalary\tDateOfjoining");
		for(Employee employee:employees)
			System.out.println(employee.getEmpID() +"\t\t"
					+employee.getFirstName()+"\t\t" 
					+employee.getLastname()+"\t\t" 
					+employee.getSalary()+"\t\t" 
					+employee.getEmpdoj() );
		
	}

}
