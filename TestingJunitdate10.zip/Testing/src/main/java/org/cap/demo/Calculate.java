package org.cap.demo;

public class Calculate {
	
	public int addArray(int ... nums)
	{
		int sum=0;
		for(int num:nums)
		{
			sum+=num;
		}
		return sum;
	}
	public int cal(int num1,int num2)
	{
		int num=num1+num2;
		System.out.println(num);
		return num;
	}

}
