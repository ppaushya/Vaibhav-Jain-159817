package org.cap.file;

import java.io.File;
import java.io.IOException;

public class Filedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=new File("C:\\demo1\\filedemo\\mydemp.txt");
		if(file.exists())
		{
			System.out.println("Readable: "+ file.canRead());
			System.out.println("Writable: "+ file.canWrite());
			System.out.println("Executable: "+ file.canExecute());
			System.out.println("path: "+ file.getAbsolutePath());
		}
		else 
		{
			System.out.println("File does not exist!!");
		    if(file.isDirectory()) 
		   {
			String[] names=file.list();
			for(String name:names)
				System.out.println(name);
	     	}
		   else
		 {
	 		System.out.println("Sorry! No such Directory Exists!");
		}
		    try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
	}
	}
}
