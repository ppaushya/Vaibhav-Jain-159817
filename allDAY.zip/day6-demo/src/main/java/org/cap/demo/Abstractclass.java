package org.cap.demo;

public abstract class Abstractclass {

	abstract void print();
	
	public static void main(String[] args) {
	 

	}

}
