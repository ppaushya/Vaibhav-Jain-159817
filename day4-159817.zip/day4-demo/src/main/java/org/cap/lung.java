package org.cap;

import java.util.Arrays;

public class lung {

	public static void main(String[] args) {
		int[] arr= {10,-7,8,56,34,-89};
		/*arr=new String[5];
		arr[0]="Jones";
		arr[1]="nhjk";
		arr[2]="vbhg";
		arr[3]="Abgh";
		arr[4]="abcd";*/
		Arrays.sort(arr);
		
		int result= Arrays.binarySearch(arr,56);
		
		
		//for(int i=0;i<arr.length;i++)
			System.out.println(result);

	}

}
