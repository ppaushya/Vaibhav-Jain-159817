package org.cap.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="employee_info")
public class employee {
	
	    @Id
	    @GeneratedValue
		private int empId;
		@Column(name="fname",nullable=false)
	    private String firstName;
		private String lastName;
		private double salary;
		@Temporal(value=TemporalType.TIME)
		private Date DOJ;
		@Transient
		private String userPass;
		
		
		
		
		public employee() {
			
		}

		
		public employee(int empId, String firstName, String lastName, double salary, Date dOJ, String userPass) {
			super();
			this.empId = empId;
			this.firstName = firstName;
			this.lastName = lastName;
			this.salary = salary;
			DOJ = dOJ;
			this.userPass = userPass;
		}


		public employee(int empId, String firstName, String lastName, double salary) {
			super();
			this.empId = empId;
			this.firstName = firstName;
			this.lastName = lastName;
			this.salary = salary;
		}
		public employee( String firstName, String lastName, double salary) {
			super();
			//this.empId = empId;
			this.firstName = firstName;
			this.lastName = lastName;
			this.salary = salary;
		}

		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
		
		
		
		public Date getDOJ() {
			return DOJ;
		}

		public void setDOJ(Date dOJ) {
			this.DOJ = dOJ;
		}

		public String getUserPass() {
			return userPass;
		}

		public void setUserPass(String userPass) {
			this.userPass = userPass;
		}

		@Override
		public String toString() {
			return "employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
					+ "]";
		}
		
	    

	}



