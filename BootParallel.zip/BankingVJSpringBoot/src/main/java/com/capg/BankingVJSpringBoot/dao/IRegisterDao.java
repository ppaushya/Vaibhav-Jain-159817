package com.capg.BankingVJSpringBoot.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.BankingVJSpringBoot.model.Customer;


@Repository("registerDao")
@Transactional
public interface IRegisterDao extends JpaRepository<Customer, Long>{

	//public void save(Customer customer);
	

}
