package org.cap.demo;

public class helloworld {

	public static void main(String[] args) {
		System.out.println("Hello World! from IDE");// TODO Auto-generated method stub

	}

}
