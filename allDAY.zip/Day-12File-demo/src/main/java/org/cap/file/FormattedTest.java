package org.cap.file;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FormattedTest {
      static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
            String empName;
            int empID;
            double salary;
            boolean isPermanent;
            char gender;
            int length;
            
            File file=new File("C:\\demo\\filedemo\\mydata.txt");
            try(FileOutputStream stream=new FileOutputStream(file);
            		DataOutputStream outputstream=new DataOutputStream(stream)){
            	       
            	   for(int i=0;i<5;i++)
            	   {
            		   outputstream.writeInt(empID=sc.nextInt());
            		   outputstream.writeDouble(salary=sc.nextDouble());
            		   outputstream.writeBoolean(isPermanent=sc.nextBoolean());
            		   outputstream.writeChar(gender=sc.nextChar());
            		   outputstream.write(empName.getBytes()=sc.next());
            		   outputstream.writeInt(length=empName.length());
            	   }
            	
           } catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            try(FileOutputStream stream=new FileOutputStream(file);
            		DataOutputStream outputstream=new DataOutputStream(stream)){
            	       
            
            
	}

}
