import { Component } from "@angular/core";

@Component({
    templateUrl:'./mainPage.component.html',
    styleUrls:['./mainPage.component.css']
})
export class MainPageComponent{

}