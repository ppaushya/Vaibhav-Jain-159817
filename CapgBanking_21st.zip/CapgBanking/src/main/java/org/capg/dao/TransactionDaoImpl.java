package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.capg.model.Transaction;

public class TransactionDaoImpl implements ITransactionDao{
	

	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "navkar");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	

	@Override
	public boolean createTransaction(Transaction transaction) {
		    boolean flag=false;
		    String sql="insert into acc_transaction(transactionDate,fromAccount,toAccount,amount,description,transactionType,customerId) values(?,?,?,?,?,?,?);";
		    try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
		    	
		    	pst.setDate(1, Date.valueOf(transaction.getTransactionDate()));
		    	pst.setInt(2, transaction.getFromAccount());
		    	pst.setInt(3, transaction.getToAccount());
		    	pst.setDouble(4, transaction.getAmount());
		    	pst.setString(5, transaction.getDescription());
		    	pst.setString(6, transaction.getTransactionType());
		    	pst.setInt(7, transaction.getCustomerId());
		    	int count=pst.executeUpdate();
		    	if(count>0)
		    	{
		    		flag=true;
		    	}
		    	else flag=false;
		    	
		    	
		    	
		    	
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return flag;
	}


	@Override
	public boolean createFundsTransaction(Transaction transaction) {
		  boolean flag=false;
		    String sql="insert into acc_transaction(transactionDate,fromAccount,toAccount,amount,description,transactionType,customerId) values(?,?,?,?,?,?,?);";
		    try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
		    	
		    	pst.setDate(1, Date.valueOf(transaction.getTransactionDate()));
		    	pst.setInt(2, transaction.getFromAccount());
		    	pst.setInt(3, transaction.getToAccount());
		    	pst.setDouble(4, transaction.getAmount());
		    	pst.setString(5, transaction.getDescription());
		    	pst.setString(6, transaction.getTransactionType());
		    	pst.setInt(7, transaction.getCustomerId());
		    	int count=pst.executeUpdate();
		    	if(count>0)
		    	{
		    		flag=true;
		    	}
		    	else flag=false;
		    	
		    	
		    	
		    	
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return flag;
	}


	

}
