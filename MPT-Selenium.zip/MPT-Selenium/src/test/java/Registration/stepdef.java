package Registration;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetTitle;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	private WebDriver webdriver;
	private WebElement element;
	
	@Before
	public void setUp() {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\vjain7\\Downloads\\chromedriver.exe");
	webdriver= new ChromeDriver();
	}
	
	
	@Given("^open conference registration page$")
	public void open_conference_registration_page() throws Throwable {
		webdriver.get("http://localhost:8081/MPT-Selenium/");
		String string=webdriver.findElement(By.tagName("h4")).getText();
		if(!webdriver.getTitle().equals("Conference Registartion")|| !string.equals("Step 1: Personal Details")) {
			webdriver.quit();
		}
		
		
	}

	@Given("^provide registration details$")
	public void provide_registration_details() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("sam");
		//webdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);
		webdriver.findElement(By.name("txtLN")).sendKeys("jackson");
		Thread.sleep(3000);
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		Thread.sleep(3000);
		webdriver.findElement(By.name("Phone")).sendKeys("9877076360");
		Thread.sleep(3000);
		Select select=new Select(webdriver.findElement(By.name("size")));		
		select.selectByIndex(3);
		Thread.sleep(3000);
		webdriver.findElement(By.name("Address")).sendKeys("North America");
		Thread.sleep(3000);
		webdriver.findElement(By.name("Address2")).sendKeys("US");
		Thread.sleep(3000);
		Select city=new Select(webdriver.findElement(By.name("city")));
		city.selectByIndex(2);
		Thread.sleep(3000);
		Select state=new Select(webdriver.findElement(By.name("state")));
		state.selectByIndex(2);
		Thread.sleep(3000);
//		Select status=new Select(webdriver.findElement(By.name("memberStatus")));
//		status.selectByIndex(1);
		webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input")).click();
		Thread.sleep(5000);
		
		
		
	}

	@When("^click on Next button$")
	public void click_on_Next_button() throws Throwable {
	   webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	}

	@Then("^navigate to payment details page$")
	public void navigate_to_payment_details_page() throws Throwable {
		webdriver.switchTo().alert().accept();
	}
	
	@Given("^Payment Details page$")
	public void payment_Details_page() throws Throwable {
		webdriver.get("http://localhost:8081/MPT-Selenium/PaymentDetails.html");
	}

	@Given("^provide payment details$")
	public void provide_payment_details() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Sam");
		//webdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);
		webdriver.findElement(By.name("debit")).sendKeys("150056741300");
		Thread.sleep(3000);
		webdriver.findElement(By.name("cvv")).sendKeys("140");
		Thread.sleep(3000);
		webdriver.findElement(By.name("month")).sendKeys("Nov");
		Thread.sleep(3000);
		webdriver.findElement(By.name("year")).sendKeys("2025");
		Thread.sleep(3000);
	}

	@When("^click on Make Payment$")
	public void click_on_Make_Payment() throws Throwable {
		 webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	}

	@Then("^navigate to confirmation box$")
	public void navigate_to_confirmation_box() throws Throwable {
		webdriver.switchTo().alert().accept();
	}



}
