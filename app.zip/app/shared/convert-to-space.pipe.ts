import { Pipe, PipeTransform } from "@angular/core";
import { ValueTransformer } from "@angular/compiler/src/util";

@Pipe({
    name: 'convertTospaces'
})
export class ConvertToSpacePipe implements PipeTransform{
    transform(value:string,character:string):string{
        return value.replace(character,'/');
    }
}