package com.capg.BankingVJSpringBoot.service;

import java.util.Date;
import java.util.List;

import com.capg.BankingVJSpringBoot.model.Transaction;

public interface ITransactionService {

	public boolean createTransaction(Transaction transaction);

	public List<Transaction> getAllTransactionsOfCustomer(Integer customerId);

	public List<Transaction> getAllTransactionsOfCustomerBetweenDates(Integer customerId, Date fromDate, Date toDate);

	public List<Transaction> getAllTransactionsOfAccount(Integer accountId);
	
	

}
