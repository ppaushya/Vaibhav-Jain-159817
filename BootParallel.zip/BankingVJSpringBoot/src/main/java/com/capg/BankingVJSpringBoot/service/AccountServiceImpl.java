package com.capg.BankingVJSpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.BankingVJSpringBoot.dao.IAccountDao;
import com.capg.BankingVJSpringBoot.model.Account;

@Service("accountService")
public class AccountServiceImpl implements IAccountService{

	
	@Autowired
	private IAccountDao accountDao;
	@Override
	public boolean addAccount(Account account) {
		accountDao.save(account);
		return true;
	}
	@Override
	public List<Account> getAccountByCustomerCustomerId(Long customerId) {
		return accountDao.getAccountNumberByCustomerCustomerId(customerId);
	}
	@Override
	public List<Account> getAllAccounts() {
		return accountDao.findAll();
		}

}
