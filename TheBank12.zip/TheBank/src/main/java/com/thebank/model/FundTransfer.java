package com.thebank.model;

import java.time.LocalDate;

public class FundTransfer {

	private long fundTranferId;
	private long accountId;
	private long payeeAccountId;
	private LocalDate dateOfTransfer;
	private double transferAmount;
	
	public FundTransfer() {
		super();
	}
	public long getFundTranferId() {
		return fundTranferId;
	}
	public void setFundTranferId(long fundTranferId) {
		this.fundTranferId = fundTranferId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(long payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public LocalDate getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(LocalDate dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public double getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(double transferAmount) {
		this.transferAmount = transferAmount;
	}
	public FundTransfer(long accountId, long payeeAccountId, LocalDate dateOfTransfer, double transferAmount) {
		super();
		this.accountId = accountId;
		this.payeeAccountId = payeeAccountId;
		this.dateOfTransfer = dateOfTransfer;
		this.transferAmount = transferAmount;
	}
}
