package Practice;

public class TestMultipleInheritence {

	public static int add(final int num1,final int num2)
	{
		return num1+num2;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Child c =new Child();
		c.show();*/

		/*Parent p=new Child();
		p.show();*/
		
		//System.out.println(add(55,45));
		
		//Child c=new Child();
		
		GrandParent gp=new Child();
		
		/*System.out.println();
		Parent p=new Child();
		
		System.out.println();
		Child c=new Child();*/
	}

}
