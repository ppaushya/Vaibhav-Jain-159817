package org.cap.date;

import java.sql.Time;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Date;

public class briges {

	public static void main(String[] args) {
		Instant ins=Instant.now();
		System.out.println(ins);
		Date newdate=Date.from(ins);
		System.out.println(newdate);
		Instant newIns=newdate.toInstant();
		System.out.println(newIns);
		Date date1=new Date();
		System.out.println(date1);
		
		 
		
		
		

	}

}
