package org.cap.service;

import org.cap.model.Registration;

public interface ICustomerRegistration {

	public void createCustomer(Registration customer);
	 

}
