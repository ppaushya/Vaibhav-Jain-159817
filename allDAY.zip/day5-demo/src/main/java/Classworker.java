
public abstract class Classworker {
	
	String name;
	
	public Classworker(String name) {
		this.name = name;
	}
	public abstract float comPay();
	public abstract void show();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
