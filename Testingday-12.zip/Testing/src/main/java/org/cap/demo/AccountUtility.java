package org.cap.demo;

public class AccountUtility {
	public static int generateAccountNo() {
		return (int)(Math.random()*1000);
	}

}
