package org.cap.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

public class Collectiondemo {

	public static void main(String[] args) {
            
		//ArrayList list=new ArrayList<>();
		//ArrayList list1=new ArrayList<>();
		LinkedList<String> list2=new LinkedList<>();
		
		//Vector<String> list=new Vector<>();
		//Collection list=new ArrayList<>();
		//Iterable list=new ArrayList<>();
		//list.add(3);
	/*	list.add("Tom");
		list.add("Jerry");
		list.add("Tom");
		list1.add("Tom");
		list1.add("Jerry");
		list1.add("Tom");
		list1.add(null);*/
		//list.add(45.89);
		//list.add(423434983);
		//list.add(new Object());
		//list.add(45.89);
		//list.add(null);
		//System.out.println(list.addAll(list));
		//System.out.println(list.size());
		//System.out.println(list.contains("Tom"));
		//list.clear();
		//System.out.println(list);
		//System.out.println(list.isEmpty());
		//System.out.println(list.get(3));
	//	Object[] obj=list.toArray();
	//	System.out.println(obj);
		//System.out.println(list.clone());
		//System.out.println(list.containsAll(list));
		
	//	list.ensureCapacity(100);
		//System.out.println(list.equals(list1));
		//System.out.println(list.indexOf("Tom"));
		
		//Enhancedforloop
		/*for(String str:list) {
		System.out.print(str+" ");
		}
		System.out.println();
		//Iterator<String> iterator=list.iterator();
		//while(iterator.hasNext()) {
			//String str=iterator.next();
			//System.out.print(str+" ");
		//}
		
	 ListIterator<String> listiterator=list.listIterator();
	 while(listiterator.hasNext())
	 {
		 String str=listiterator.next();
		 System.out.print(str+"-->");
	 }
	 System.out.println();
	 //ListIterator<String> listiterator=list.listIterator();
	 while(listiterator.hasPrevious())
	 {
		 String str=listiterator.previous();
		 System.out.print(str+"-->");
	 }
	 System.out.println();
	 
	 Enumeration<String> enumeration=list.elements();
	 while(enumeration.hasMoreElements())
	 {
		 String str=enumeration.nextElement();
		 System.out.print+(str+" ");

	 }
	 */
	 
	 
	 
	 

	}

}
