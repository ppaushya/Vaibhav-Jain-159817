package org.capg.service;

import java.time.LocalDate;

import org.capg.model.Customer;

public class CustomerServiceImp1 implements iCustomerService {

	private boolean isValidCustomer(Customer customer)
	{
		boolean flag=false;
		if(customer.getDateofBirth().isBefore(LocalDate.now())) {
			if(customer.getMobileNo().matches("[789]{1}[0-9]{9}")))
                flag=true;
             else
                flag=false;
		}else flag=false;
	}
	return flag
}
