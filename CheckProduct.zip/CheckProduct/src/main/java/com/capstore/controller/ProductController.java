package com.capstore.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.service.IProductService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api/v1")
public class ProductController {
	
	@Autowired
	private IProductService productService;
	
	@GetMapping("/products/bestSellerInfo")
	public ResponseEntity<Map<String, Integer>> getBestSellerInfo(){
		Map<String, Integer> productBestSeller=productService.getBestSellerId();
		if(productBestSeller.isEmpty())
			return new ResponseEntity("Sorry! No Products Available!", HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<Map<String, Integer>>(productBestSeller, HttpStatus.OK);
	}
	
	@GetMapping("/products/quantity")
	public ResponseEntity<Map<String, Long>> getProductQuantityInfo(){
		Map<String, Long> productQuantity=productService.getProductQuantity();
		if(productQuantity.isEmpty())
			return new ResponseEntity("Sorry! No Products Available!", HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<Map<String, Long>>(productQuantity, HttpStatus.OK);
	}
	
	@GetMapping("/products/sales")
	public ResponseEntity<Map<String, Long>> getProductSalesInfo(){
		Map<String, Long> productSales=productService.getProductSales();
		if(productSales.isEmpty())
			return new ResponseEntity("Sorry! No Products Available!", HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<Map<String, Long>>(productSales, HttpStatus.OK);
	}
}