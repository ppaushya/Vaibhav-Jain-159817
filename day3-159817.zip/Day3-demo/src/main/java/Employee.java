import java.util.Scanner;

public class Employee {
	
	Scanner sc=new Scanner(System.in);
	String firstname;
	String lastname;
	int empID;
	double salary;
	
	public void getEmployeedetails()
	{
		
		System.out.println("Enter the First Name :");
		firstname=sc.next();
		System.out.println("Enter the Last Name :");
		lastname=sc.next();
		System.out.println("Enter the EmpID :");
		empID=sc.nextInt();
		System.out.println("Enter the Salary :");
		salary=sc.nextDouble();
	}
	public void printdetails()
	{
		System.out.println("FirstName : "+firstname);
		System.out.println("LastName : "+lastname);
		System.out.println("EmpID: "+empID);
		System.out.println("Salary : "+salary);
	}
 



	public static void main(String[] args) {
		Mainclass obj=new Mainclass();
		obj.acceptEmployee(2);
		obj.printEmployeedetails();
		obj.sortEmployees();
		System.out.println("Sorted Array :");
		obj.printEmployeedetails();
	}
}

		// TODO Auto-generated method stub

	


