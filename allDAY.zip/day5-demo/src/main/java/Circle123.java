
public class Circle123 implements Interfaces1 {

	public void draw()
	{
		System.out.println("Circle classs with draw method");
	}
	public void info()
	{
		System.out.println("Circle classs with info method");
	}
	
	public static void main(String[] args) {
	  Interfaces1 obj=new Circle123();
	  obj.info();
	  obj.draw();
	  obj.shapepoints();
	 

	}

}
