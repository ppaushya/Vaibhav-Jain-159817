package day6miniproject;

import java.util.Scanner;

import javax.swing.text.html.CSS;

import java.util.*;


public class Bootclass {

	public static void main(String[] args) {
	
		
	 
	  
	  ArrayList<Customer> customers= new ArrayList<>();
		
	  ArrayList<Address> address = new ArrayList<>();
	 
		
		int i;
		
		Scanner s = new Scanner(System.in);
		
		
		String name,mailid,mobileno;
		
		int cid;
		
		boolean z = true;
		
		for(i=0;i<2;i++)
		{
			System.out.println("enter the " + (i+1) +" name of the customer ");
			
			name= s.next();
			

			while(z)
			{
			if(name.matches("[A-Za-z]+"))
			{
				System.out.println("valid name");
				z=false;
			}
			else
			{
				System.out.println("not a valid name enter one more time");
				name=s.next();
				
			}
			}
			
			z=true;
		    
			System.out.println("enter the " +(i+1) + "id of the customer");
			
			cid=s.nextInt();
			
			
			while(z)
			{
			if(Integer.toString(cid).matches("[0-9]{6,10}"))
			{
				System.out.println("valid cust id");
				z=false;
			}
			else
			{
				System.out.println("not a valid id enter one more time");
				cid=s.nextInt();
				
			}
			
			}
			z=true;
			
			System.out.println("enter the " +(i+1) + "mail id of the customer");
			
			mailid=s.next();
			
			while(z)
			{
			if(mailid.matches("[a-zA-z0-9]+[@]{1}(gmail){1}[.]{1}(com){1}"))
			{
				System.out.println("valid cust mail id");
				z=false;
			}
			else
			{
				System.out.println("not a valid email id enter one more time");
				mailid=s.next();
				
			}
			}
		
			z=true;

			System.out.println("enter the " +(i+1) + "mobile no of the customer");
			
			mobileno=s.next();
			
			while(z)
			{
			if(mobileno.matches("[0-9]{6,10}"))
			{
				System.out.println("valid cust mobile no");
				z=false;
			}
			else
			{
				System.out.println("not a valid mobile no enter one more time");
				mobileno=s.next();
				
			}
			}
		   	
			customers.add(new Customer(cid,name,mailid,mobileno));
			
		}
		
		
		
	 for(Customer cs: customers)
			{
				System.out.println(cs.getCustomerId() + "  " + cs.getCustomerName() + " " + cs.getMobileno());
			}
	
	 
	      Iterator<Customer> cst = customers.iterator();
	      Iterator<Customer> cst2 = customers.iterator();
		boolean flag=true;
		
		int temp,var,num;
		int part,accno=100;
		String type=" ";
		float bal=1000;
		Account checkuser= new Account(accno,type,bal);
		while(flag)
		{
			System.out.println("enter 1 to view/generateaccount/dotransaction for " + customers.get(0).getCustomerName() );
			System.out.println("enter 2 to view/generateaccount/dotransaction for " + customers.get(1).getCustomerName());
		//	System.out.println("enter 3 to view/generateaccount/dotransaction for " + customers.get(2).getCustomerName());
			//System.out.println("enter 4 to view/generateaccount/dotransaction for " + customers.get(3).getCustomerName());
			//System.out.println("enter 5 to view/generateaccount/dotransaction for " + customers.get(4).getCustomerName());
		
			num=s.nextInt();
			
			System.out.println("1.create account for " +customers.get(num-1).getCustomerName());
			System.out.println("2.do transaction for " +customers.get(num-1).getCustomerName());
			System.out.println("3.view transaction for " +customers.get(num-1).getCustomerName());
			
			temp=s.nextInt();
			
			
			if(temp==1)
			{
				System.out.println("create an account");
				accno=1000;
				bal=1000;
				type=s.next();
						
				if(customers.get(num-1).accounts.contains(checkuser))
				{
					System.out.println("account already exists");
				}
				else
				{
					System.out.println("in process");
				customers.get(num-1).accounts.add(checkuser);
				}
			}
			
			for(i=0;i<customers.get(num-1).accounts.size();i++)
			{
				System.out.println(customers.get(num-1).accounts.get(i));
			}
			
		   System.out.println("enter 1 to continue and 2 to exit");
		   
		   part=s.nextInt();
		   
		   if(part==2)
		   {
			   flag=false;
		   }
		   
		}
		
	}
		/*
			num=s.nextInt();
		    
			
			
			System.out.println("1.create account for "+c[num-1].getCustomerName());
			System.out.println("2.do transaction for " +c[num-1].getCustomerName());
			System.out.println("3.view transaction for " +c[num-1].getCustomerName());
			
			temp=s.nextInt();
			
			
			if(temp==1)
			{
				System.out.println("1.create debit account");
				System.out.println("2.create savings account");
				System.out.println("3.create salary account");
				System.out.println("4.create fd account");
				System.out.println("5.create rd account");
				var=s.nextInt();	
				if(c[num-1].account[var-1].getBalance()>=1000)
				{
					System.out.println("account is already created with " + c[num-1].getCustomerName() + " " + c[num-1].account[var-1].getAccno() + " " + c[num-1].account[var-1].getAcctype());
				}
				else
				{
				c[num-1].account[var-1].setAccno(10000+num);
				
				if(var==1)
				{
					c[num-1].account[var-1].setAcctype("debit");
				}
				else if(var==2)
				{
					c[num-1].account[var-1].setAcctype("savings");
				}
				else if(var==3)
				{
					c[num-1].account[var-1].setAcctype("salary");
				}
				else if(var==4)
				{
					c[num-1].account[var-1].setAcctype("fd");
				}
				else if(var==5)
				{
					c[num-1].account[var-1].setAcctype("rd");
				}
				c[num-1].account[var-1].setBalance(1000);
				}
				for(int k=0;k<5;k++)
				{
					if(c[num-1].account[k].getAccno()>=100)
					{
						count++;
						
					}
					
				}
				System.out.println(c[num-1].getCustomerName() + " has total " + count + "accounts");
				count=0;
				
			}
			else if(temp==2)
			{

				System.out.println("1.transact with debit account");
				System.out.println("2.transact with savings account");
				System.out.println("3.transact with salary account");
				System.out.println("4.transact with fd account");
				System.out.println("5.transact with rd account"); 
				count=s.nextInt();
				
				c[num-1].account[count-1].trans[l].setTransid(1000+l);
				
				System.out.println("enter 1 to deposit and 2 to withdraw");
				
				t=s.nextInt();
				
				if(t==1)
				{
					System.out.println("enter amount to add");
					balance=s.nextInt();
					c[num-1].account[count-1].trans[l].setType("depositing");
					c[num-1].account[count-1].setBalance((c[num-1].account[count-1].getBalance()) + (balance));
					c[num-1].account[count-1].trans[l].setAmount(balance);
				 	m=c[num-1].account[count-1].getBalance();
					c[num-1].account[count-1].trans[l].setUpdated(m);
					l++;
				}
				else
				{

					System.out.println("enter amount to withdraw");
					balance=s.nextInt();
					c[num-1].account[count-1].trans[l].setType("withdrawing");
					c[num-1].account[count-1].setBalance((c[num-1].account[count-1].getBalance()) - (balance));
					c[num-1].account[count-1].trans[l].setAmount(balance);
				 	m=c[num-1].account[count-1].getBalance();
					c[num-1].account[count-1].trans[l].setUpdated(m);
					l++;
				}
				
			}
			else if(temp==3)
			{
				System.out.println("l is " +l);
		        
				 System.out.println("1.transact with debit account");
					System.out.println("2.transact with savings account");
					System.out.println("3.transact with salary account");
					System.out.println("4.transact with fd account");
					System.out.println("5.transact with rd account"); 
					count=s.nextInt();
				
				for(int k=0;k<l;k++)
		         {			
		        	 System.out.println("transid is " + c[num-1].account[count-1].trans[k].getTransid() );
		        	 System.out.println("transtype is " +c[num-1].account[count-1].trans[k].getType());
		        	 if(c[num-1].account[count-1].trans[k].getAmount()>0)
		        	 {
		        	 System.out.println("added balance is " +c[num-1].account[count-1].trans[k].getAmount());
		        	 }
		        	 else
		        	 {
		        		 System.out.println("subracted balance is " +c[num-1].account[count-1].trans[k].getAmount()); 
		        	 }
		        	 System.out.println("updated balance is " +c[num-1].account[count-1].trans[k].getUpdated());
		         }
		         if(l==0)
		         {
		        	 System.out.println("there are no transactions to view");
		         }
			}
			System.out.println("enter 1 to continue and 2 to exit");
			
			cont=s.nextInt();
			
			if(cont==2)
			{
				flag=false;
			}
			
*/			
		}
		

	


