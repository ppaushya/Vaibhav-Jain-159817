package org.capg.dao;

import org.capg.model.Transaction;

public interface ITransactionDao {

	public boolean createTransaction(Transaction transaction);

	public boolean createFundsTransaction(Transaction transaction);

}
