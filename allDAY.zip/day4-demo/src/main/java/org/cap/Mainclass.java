package org.cap;

public class Mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Weekdays myday=Weekdays.MON;
          
          switch(myday)
          {
        	  case SUN:
        		  System.out.println("Holiday");
        		  	break;
        	  case SAT:
        		  System.out.println("Working Day");
        		  	break;
        	  case MON:
        		  System.out.println("Working Day");
        		  	break;
        	  case TUE:
        		  System.out.println("Working day");
        		  	break;
        	  case FRI:
        		  System.out.println("Holiday");
        		  	break;
        	default:
       
      		  System.out.println("Special Day");
      		  	break;
          }
	}

}
