package com.capg.BankingVJSpringBoot.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.BankingVJSpringBoot.model.Customer;

@Repository("loginDao")
@Transactional
public interface ILoginDao extends JpaRepository<Customer, Long>{

	public Customer getCustomerByEmailIdAndPassword(String userName, String password);

	

}
