package com.capg.BankingVJSpringBoot.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="transaction")
public class Transaction {
	
	@Id
	@GeneratedValue
	private long transactionId;

	@JsonFormat(pattern="dd-MMM-yyyy")
	@DateTimeFormat(pattern="dd-MMM-yyyy")
	@Temporal(TemporalType.DATE)
	private Date transactionDate;
	
	@OneToOne
	private Account fromAccount;

	@OneToOne
	private Account toAccount;
	
	private double amount;
	private String transactionType;
	private String description;
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public Account getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(Account fromAccount) {
		this.fromAccount = fromAccount;
	}
	public Account getToAccount() {
		return toAccount;
	}
	public void setToAccount(Account toAccount) {
		this.toAccount = toAccount;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Transaction(long transactionId, Date transactionDate, Account fromAccount, Account toAccount, double amount,
			String transactionType, String description) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.amount = amount;
		this.transactionType = transactionType;
		this.description = description;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate + ", fromAccount="
				+ fromAccount + ", toAccount=" + toAccount + ", amount=" + amount + ", transactionType="
				+ transactionType + ", description=" + description + "]";
	}
	
	

}
