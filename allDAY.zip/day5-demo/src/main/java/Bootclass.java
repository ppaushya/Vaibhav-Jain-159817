
public class Bootclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Student student=new Student();
         student.setStudenID(1000);
         student.setFirstname("Jerry");
         student.setLastname("Tom");
         student.setRegFees(34000);
         
         System.out.println(student.getStudenID()+student.getFirstname()+ student.getLastname());
	}

}
