package org.cap;

import java.util.Scanner;

public class method {
	double principle;
	int years;
	double rate;
	
	public method() {
		super();
		principle=1000;
		rate=4.4;
		years=3;
	}

	public double calInterest()
	{
		
		double t=(principle*rate*years)/100;
		return t;
	}

	public double calInterest(double principle)
	{
		
		double t=(principle*rate*years)/100;
		return t;
	}

	public double calInterest(double principle, int years)
	{
		
		double t=(principle*rate*years)/100;
		return t;
	}

	public double calInterest(double principle,int years, double rate)
	{
		
		double t=(principle*rate*years)/100;
		return t;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		method obj=new method();
		double a=obj.calInterest();
		System.out.println(a);
		double b=obj.calInterest(4000);
		System.out.println(b);
		double c=obj.calInterest(5000,5);
		System.out.println(c);
		double d=obj.calInterest(6000,6,10);
		System.out.println(d);
		
		
		
		

	}

}
