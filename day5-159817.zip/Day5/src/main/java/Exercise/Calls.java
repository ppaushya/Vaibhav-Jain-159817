package Exercise;

public abstract class Calls {
	int hrs;

	/*public Calls() {
		super();
	}*/

	public Calls(int hrs) {
		super();
		this.hrs = hrs;
	}
	public abstract int charge(int hrs);
	

}
