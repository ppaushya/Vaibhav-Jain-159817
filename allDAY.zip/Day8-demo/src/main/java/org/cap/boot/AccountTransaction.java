package org.cap.boot;


import org.cap.boot.Account;
import org.cap.boot.Customer;

public class AccountTransaction {
	public static long generateAccountNo() {
		return (long)Math.random()*10000;
	}

	public Account findAccount(long accountNo,Customer customer) {
		
		
		for(Account account:customer.getAccount()) {
			if(account!=null) {
				if(account.getAccountNo()==accountNo) {
					return account;
				}
			}
		}
		
		return null;
	}
}
	