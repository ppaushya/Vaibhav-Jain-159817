
public class Nestedwhile {

	public static void main(String[] args) {
		int co=5;
		int num=1;
		int count=5;
		while(num<=100)
		{
			while(count>0)
			{
			if(num%2==0)
			  {
				if(count==co)
				System.out.print(num +" ");
				else
					System.out.print(" * ");
			    count--;
			}
			num++;
				}
			if(count==0)
			{
				count=5;
				System.out.println();
				co--;
			}
			if(co==0)
			{
				co=5;
				
			}
			
		}

	}

}
