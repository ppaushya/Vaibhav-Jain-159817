import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.cap.boot.Account;
import org.cap.boot.AccountType;

public class Customobj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Account> account=new ArrayList<>();
		
		account.add(new Account(1,AccountType.SAVINGS,LocalDate.now(),34000));
		account.add(new Account(2,AccountType.RD,LocalDate.now(),13000));
		account.add(new Account(3,AccountType.FD,LocalDate.now(),45000));
		
		Iterator<Account> itr=account.iterator();
		while(itr.hasNext())
		{
			Account acc=itr.next();
			System.out.print(acc+" ");
		}
		System.out.println();


	}

}
