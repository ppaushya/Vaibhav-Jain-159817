package com.thebank.model;

public class User {
	
	private long customerId;
	private String userName;
	private String loginPassword;
	private String secretQuestion;
	private String secretQuestionAnswer;
	private String transactionPassword;
	private char lockStatus;
	
	public User() {
		super();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getSecretQuestionAnswer() {
		return secretQuestionAnswer;
	}

	public void setSecretQuestionAnswer(String secretQuestionAnswer) {
		this.secretQuestionAnswer = secretQuestionAnswer;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public char getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(char lockStatus) {
		this.lockStatus = lockStatus;
	}

	@Override
	public String toString() {
		return "User [customerId=" + customerId + ", userName=" + userName + ", loginPassword=" + loginPassword
				+ ", secretQuestion=" + secretQuestion + ", secretQuestionAnswer=" + secretQuestionAnswer
				+ ", transactionPassword=" + transactionPassword + ", lockStatus=" + lockStatus + "]";
	}

	public User(long customerId, String userName, String loginPassword, String secretQuestion,
			String secretQuestionAnswer, String transactionPassword, char lockStatus) {
		super();
		this.customerId = customerId;
		this.userName = userName;
		this.loginPassword = loginPassword;
		this.secretQuestion = secretQuestion;
		this.secretQuestionAnswer = secretQuestionAnswer;
		this.transactionPassword = transactionPassword;
		this.lockStatus = lockStatus;
	}
	
	
}
