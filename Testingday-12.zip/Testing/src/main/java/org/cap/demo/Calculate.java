package org.cap.demo;

public class Calculate {
	public int cal(int num1,int num2)
	{
		int num=num1+num2;
		System.out.println(num);
		return num;
	}

}
