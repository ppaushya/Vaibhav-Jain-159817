package InterfacePractice;

public interface Shape {

	int num=100;//jvm bydefault provide public final static int num=100
	//public abstract is bydefault provided by jvm if u dont write
	public abstract void draw();
	public abstract void info();
	//static method using interfaces or classes
	//
	public static void show()
	{
		System.out.println("Shape--static--show");
		
	}
	
	//default method can be called directly
	//need not implement in subclass
	//it gives default behaviour
	//accessed within same interface
	//always public
	default void fill()
	{
		System.out.println("Shape--default--details");
	}
	
	private void details()
	{
		System.out.println("Shape--default--details");
	}
}
