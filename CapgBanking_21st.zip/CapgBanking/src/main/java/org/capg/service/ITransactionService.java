package org.capg.service;

import org.capg.model.Transaction;

public interface ITransactionService {

	public boolean createTransaction(Transaction transaction);

	public boolean createFundsTransaction(Transaction transaction);
}
