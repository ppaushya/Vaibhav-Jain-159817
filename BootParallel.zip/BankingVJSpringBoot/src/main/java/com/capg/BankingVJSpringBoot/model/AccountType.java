package com.capg.BankingVJSpringBoot.model;

public enum AccountType {
	
	SAVINGS,CURRENT,RD,FD

}
