import org.apache.log4j.Logger;

public class HelloExample {
	
	final static Logger logger=Logger.getLogger(HelloExample.class);
	
	private void runMe(String parameter) {
		if(logger.isDebugEnabled()) {
			logger.debug("This is debug: "+parameter);
		}
		if(logger.isInfoEnabled()) {
			logger.debug("This is debug: "+parameter);
		}
		logger.warn("This is warn: "+parameter);
		logger.error("This is warn: "+parameter);
		logger.fatal("This is warn: "+parameter);
	}
	
	public static void main(String[] args) {
		HelloExample obj=new HelloExample();
		obj.runMe("Capgemini");
	}

}
