package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;



@WebServlet("/DepositWithdrawServlet")
public class DepositWithdrawServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     HttpSession session=request.getSession();
	     int custId=Integer.parseInt(session.getAttribute("CustId").toString());
		Customer customer=new Customer();
		customer.setCustomerId(custId);
		ILoginService loginservice=new LoginServiceImpl();
	     List<Account> accounts=loginservice.getAllAccounts(customer);
	     PrintWriter out=response.getWriter();
	     out.println("<html>\r\n" + 
	     		"<head>\r\n" + 
	     		"<meta charset=\"ISO-8859-1\">\r\n" + 
	     		"<title>CapgBanking</title>\r\n" + 
	     		"<link type=\"text/css\" rel=\"stylesheet\" href=\"/styles/depwith.css\">\r\n" + 
	     		"</head>\r\n" + 
	     		"<body>\r\n" + 
	     		"<form method=\"post\" action=\"TransactionServlet\">\r\n" + 
	     		"<div id=\"centercnt\">\r\n" + 
	     		"  <table>\r\n" + 
	     		"       <tr>\r\n" + 
	     		"         <th colspan=\"2\">Transaction Form</th>\r\n" + 
	     		"       </tr>\r\n" + 
	     		"         <td>Choose Account:</td>\r\n" + 
	     		"         <td>\r\n" + 
	     		"         <select name=\"accountNo\">\r\n"); 
	                       for(Account account:accounts)
	                       {
	                    	   out.println("<option value=\""+account.getAccountNumber()+"\">"+account.getAccountNumber()+"-"+account.getAccountType());
	                       }
	                       out.println("</select>\r\n" + 
	     		"         </td>\r\n" + 
	     		"       </tr>\r\n" + 
	     		"       <tr>\r\n" + 
	     		"       <td>Choose Option:</td>\r\n" + 
	     		"       <td>\r\n" + 
	     		"       <input type=\"radio\" name=\"DepWith\" value=\"Credit\">Deposit\r\n" + 
	     		"       <input type=\"radio\" name=\"DepWith\" value=\"Debit\">Withdraw\r\n" + 
	     		"       </td>\r\n" + 
	     		"       </tr>\r\n" + 
	     		"       \r\n" + 
	     		"      <tr>\r\n" + 
	     		"       <td>Amount:</td>\r\n" + 
	     		"       <td>\r\n" + 
	     		"        <input type=\"text\" name=\"amount\" size=\"20\" required>\r\n" + 
	     		"       </td>\r\n" + 
	     		"      </tr>\r\n" + 
	     		"      \r\n" + 
	     		"           \r\n" + 
	     		"      <tr>\r\n" + 
	     		"       <td>Description:</td>\r\n" + 
	     		"       <td>\r\n" + 
	     		"        <input type=\"text\" name=\"description\" size=\"20\" required>\r\n" + 
	     		"       </td>\r\n" + 
	     		"      </tr>\r\n" + 
	     		"      \r\n" + 
	     		"      <tr>\r\n" + 
	     		"      <td></td>\r\n" + 
	     		"				<td>\r\n" + 
	     		"				\r\n" + 
	     		"					<input type=\"submit\" name=\"transaction\" value=\"Do Transaction\" class=\"btnStyle\">\r\n" + 
	     		"				</td>\r\n" + 
	     		"      </tr>\r\n" + 
	     		"  \r\n" + 
	     		"  </table>\r\n" + 
	     		"  \r\n" + 
	     		"  </form>\r\n" + 
	     		"\r\n" + 
	     		"</div>\r\n" + 
	     		"\r\n" + 
	     		"</body>\r\n" + 
	     		"</html>");
	                       
	               
	     
	     
	}

}
