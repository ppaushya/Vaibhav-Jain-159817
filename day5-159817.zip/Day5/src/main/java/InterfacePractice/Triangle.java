package InterfacePractice;

public class Triangle implements Shape{
	@Override
	public void draw()
	{
		System.out.println("Class Triangle--draw");
	}
	public void info()
	{
		System.out.println("Class Triangle--info");
	}
}
