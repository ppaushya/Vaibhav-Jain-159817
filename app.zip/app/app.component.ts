import { Component } from '@angular/core';
import { ProductService } from './Product/product.service';

@Component({
  selector: 'pm-root',
  template: 
  `<div>
    <nav class='navbar navbar-default'>
       <div class='container-fluid'>
        <a class='navbar-brand'>{{pageTitle}}</a>
                       
         </div>
         </nav>
       <div class='container'>
         <router-outlet></router-outlet>
        </div>    
    </div>`
 // providers:[ProductService]
})
export class AppComponent {
  title = 'Capg Banking';
}
