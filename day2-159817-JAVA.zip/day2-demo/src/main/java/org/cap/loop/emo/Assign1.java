package org.cap.loop.emo;

import java.util.Scanner;

public class Assign1 {
	 public int getNumber()
	 {
		 Scanner scanner=new Scanner(System.in);
			System.out.println("Enter Number: ");
			int n = scanner.nextInt();
			scanner.close();
			return n;
	 }
	 
	public void sumDigits()
	{
	  int a,n,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number: ");
	  a=sc.nextInt();
	  sc.close();
	  while(a > 0)
      {
          n = a % 10;
          sum = sum + n;
          a = a / 10;
      }
      System.out.println("Sum of Digits:"+sum);
  }
	
		
	       public static boolean isPrime(int n) {  
	    	   Scanner s = new Scanner(System.in);  
		       System.out.print("Enter the first number : ");  
		       int start = s.nextInt();  
		       System.out.print("Enter the second number : ");  
		       int end = s.nextInt();  
	           if (n <= 1) {  
	               return false;  
	           }  
	           for (int i = 2; i <= Math.sqrt(n); i++) {  
	               if (n % i == 0) {  
	                   return false;  
	               }  
	           }  
	           return true;  
	       }  
 	 
	    		
	    		public void hell(String num)
	    		{
	    			int a=num.length();
	    			for(int i=0;i<a+1;i++)
	    			{
	    				for(int j=0;j<i;j++)
	    				{
	    					System.out.print(num.charAt(j));
	    				}
	    				System.out.println();
	    			}
	    		} 
	    	 
	    
	    			public void min(int num)
	    				{
	    					int a=num;
	    					for(int i=1;i<num;i++)
	    					{
	    						System.out.print(i);
	    						System.out.print("+");
	    						System.out.println(num-i);
	    						
	    					}
	    				} 
	    			 

	 

	
	public static void main(String[] args) {
		Assign1 obj=new Assign1();
		//obj.sumDigits();
		 /* System.out.println("List of prime numbers between " + start + " and " + end);  
	       for (int i = start; i <= end; i++) {  
	           if (isPrime(i)) {  
	               System.out.println(i); */ 
	        //  obj.hell("hello");
		obj.min(12);
	    }    
		}



	

