import java.util.Scanner;

public class Person {
         int personID;
         String firstname;
         String lastname;
         
         public Person()
         {
        	 
         }
         
         public Person(int personID, String firstname, String lastname) {
			
			this.personID = personID;
			this.firstname = firstname;
			this.lastname = lastname;
		}
		public void getPerson()
         {
        	Scanner sc=new Scanner(System.in);
             personID=sc.nextInt();
        	 firstname=sc.next();
         lastname=sc.next();
        	 
        			 
         }
		public void show()
		{
			System.out.println("Person cklass--> Show method");
		}
         public void showPerson()
         {
        	 System.out.println(personID+","+firstname+","+lastname);
         }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
