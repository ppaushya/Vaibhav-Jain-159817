
public class Dailyworker extends Classworker {
	
	int Salaryrate;
	
	public Dailyworker(String name,int salaryrate) {
		super(name);
		Salaryrate = salaryrate;
	}

	void comPay(int h)
	{
	System.out.println("Salary : "+Salaryrate*h);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
