package org.cap.view;

import java.util.List;
import java.util.Scanner;


import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.util.Utility;

public class UserInteraction {
	 Scanner sc=new Scanner(System.in);
	
	public Customer getCustomerDetails()
	{
		Customer customer=new Customer();
		customer.setCustomerID(Utility.generateNumber());
		customer.setFirstName(Utility.promptFirstName());
		customer.setLastName(Utility.promptLastName());
		customer.setEmailID(Utility.promptemailID());
		customer.setMobileNo(Utility.promptMobileNo());
		customer.setDateofBirth(Utility.promptDOB());
		customer.setAddress(getAddressDetails());
		return customer;
	}

	public Account getAccountDetails() {
		Account account=new Account();
		account.setAccountNumber(Utility.generateAccountNumber());
		Utility.printAccountType();
		System.out.println("Choose Account Type[1,2,3,4]:");
		int accountTypeNo=sc.nextInt();
		account.setAccountType(Utility.assignAccountType(accountTypeNo));
		account.setOpeningDate(Utility.promptopeningDate());
		account.setOpeningBalance(Utility.promptopeningBalance());
		account.setDescription(Utility.promptDescription());
		return account;
	}

	public Address getAddressDetails() {
		Address address=new Address();
		address.setAddressLine1(Utility.promptaddress1());
		address.setAddressLine2(Utility.promptaddress2());
		address.setCity(Utility.promptcity());
		address.setState(Utility.promptstate());
		address.setPincode(Utility.promptpincode());
		return address;
		
		
	}

	public static void printError(String message)
	{
		System.out.println(message);
	}

	public static void printCustomers(List<Customer> customers) {
		  System.out.println("CustomerID\tCustomerName\t\tEmailID\t\t\tMobileNo. ");
		  System.out.println("------------------------------------------------------------------------------------------------------");
		  for(Customer customer:customers) {
			  System.out.println(customer.getCustomerID()+"\t\t"+customer.getFirstName()+" "+customer.getLastName()+"\t\t"+customer.getEmailID()+"\t\t"+customer.getMobileNo());
		  }
		
	}
	
	
}
