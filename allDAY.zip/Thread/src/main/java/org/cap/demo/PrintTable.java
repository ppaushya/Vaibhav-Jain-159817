package org.cap.demo;


public class PrintTable extends Thread{
	
	private int a;
	private String str1;
	
	
	
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public PrintTable()
	{
		
	}
	public PrintTable(int i,String str) {
		  this.a=i;
		  this.str1=str;
	}
	
	synchronized public void printtable()
	{
		for(int i=1;i<=20;i++)
			System.out.println(Thread.currentThread().getName()+"--->"+i+"*"+a+"="+i*a);
	}
}
