package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Customer;

@WebServlet("/TransactionSummaryServlet")
public class TransactionSummaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 HttpSession session=request.getSession();
	     int custId=Integer.parseInt(session.getAttribute("CustId").toString());
		Customer customer=new Customer();
		customer.setCustomerId(custId);
		PrintWriter out=response.getWriter();
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>CapgBanking</title>\r\n<script type=\"text/javascript\" src=\"./script/form.js\"></script>" +  
				"<link type=\"text/css\" rel=\"stylesheet\" href=\"styles/summary.css\">\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<form method=\"post\" action=\"TransactionSummaryPost\" onsubmit=\"return validateToDate()\" name=\"trSummary\">\r\n" + 
				"<div class=\"centercnt\">\r\n" + 
				"		<table >\r\n" + 
				"			<tr>\r\n" + 
				"				<th colspan=\"3\">View Transaction Summary</th>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>From Date:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"date\" name=\"fromDate\">\r\n"+
				"				</td>\r\n" + 
				"              <td>" + 
				"				<div id=\"fromDateErrMsg\" class=\"errMsg\"></div>" + 
				"				</td>"+
				
				"		    </tr>\r\n" + 
				"		    <tr>\r\n" + 
				"				<td>To Date:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"date\" name=\"toDate\">\r\n" + 
				"				</td>\r\n" + 
				"              <td>" + 
				"				<div id=\"toDateErrMsg\" class=\"errMsg\"></div>" + 
				"				</td>"+
				"		    </tr>\r\n" + 
				"		    <tr>\r\n" + 
				"			\r\n" + 
				"				<td></td>\r\n" + 
				"				<td>\r\n" + 
				"				\r\n" + 
				"					<input type=\"submit\" name=\"transactionsummary\" value=\"Transaction Summary\" class=\"btnStyle\">\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"          </table>\r\n" + 
				"          </div>\r\n" + 
				"       </form>\r\n" + 
				"\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}

}
