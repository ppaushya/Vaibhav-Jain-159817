package org.cap.demo;

public interface IAccountService {
	public Account createAccount(Customer customer,double amount) throws InvalidAmountException;

}
