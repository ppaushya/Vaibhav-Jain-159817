package org.cap.hashing;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class TestClass {



//	private static final Comparator SortbyName = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> set=new ArrayList<>();
		set.add(new Employee(104,"Jones",LocalDate.of(2018, 9, 4)));
		set.add(new Employee(103,"Nick",LocalDate.of(2017, 10, 5)));
		set.add(new Employee(103,"Tom",LocalDate.of(2014, 12, 6)));
		set.add(new Employee(107,"Kite",LocalDate.of(2016, 8, 15)));
		set.add(new Employee(101,"Kite",LocalDate.of(2016, 8, 15)));
		Collections.sort(set); 
		Iterator<Employee> itr=set.iterator();
		 while(itr.hasNext())
		 {
			 System.out.println(itr.next());
		 }
		 System.out.println("================================");
		 Collections.sort(set,new SortbyName()); 
			Iterator<Employee> itr1=set.iterator();
			 while(itr1.hasNext())
			 {
				 System.out.println(itr1.next());
			 }
			 

	}

}
