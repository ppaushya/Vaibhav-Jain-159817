package org.cap.demo;

public interface IAccountDao {
	public boolean addAccount(Customer customer);

}
