package com.capgemini;
import static com.demo.validate.Validation.*;

import com.demo.validate.Validation;
public class testclass {

	public static void main(String[] args) {
		 //Validation obj=new Validation();
		 //obj.demo();
		 show();
		 System.out.println(num);
		 //System.out.println("Count:"+count);

	}

}
