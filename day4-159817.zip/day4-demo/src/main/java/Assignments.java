import java.util.Scanner;

public class Assignments {
  
	  String str;  
	  

		public void Primefactor()
		{
			int number;
		      Scanner sc = new Scanner(System.in);
		      System.out.println("Enter a number ::");
		      number = sc.nextInt();
		      
		      for(int i = 2; i< number; i++) {
		         while(number%i == 0) {
		            System.out.print(i+", ");
		            number = number/i;
		         }
		      }
		      if(number >2) {
		         System.out.println(number);
		      }
		   }
		

		public void AlphabetSoup(String str)
		{
			char b=0;
			int k=str.length();
		    char[]  a= new char[k];
			for(int i=0;i<k;i++)
			{
			    a[i]=str.charAt(i);
			}
		   for(int x=0;x<a.length;x++)
			{
				for(int y=x+1;y<a.length;y++)
				{
					if(a[x]>a[y])
					{
						char temp=a[x];
						a[x]=a[y];
						a[y]=temp;
					}
					
				}
				
			}
		   for(int g=0;g<a.length;g++)
		   {
			   System.out.println(a[g]);
		   }
			
		}
	public void findFactorial(int num)
	   {
		   int fact=1;
		   for(int i=num;i>=1;i--)
		   {
			 fact=fact*i;  
		   }
		   System.out.println("Factorial of number: "+fact);
	   }
	   
		   
         
           public void getString()
           {
                       System.out.println("Enter the string:");
                       Scanner sc=new Scanner(System.in);
                       str= sc.nextLine();
                       sc.close();
                      
           }
                       
           public void LetterCapitalize(String str)
           {
                                   int x=0;
                                   char[] che=new char[str.length()];
                                   for(int y=0;y<str.length();y++)
                                   {
                                               che[y]=str.charAt(y);
                                              
                                   }
                       for(int z=0;z<str.length()-1;z++)
                       {
                                   if(che[z]==' ' && che[z+1]==' ')
                                   {
                                               System.out.println("Two consecutive spaces are not allowed");
                                               System.exit(0);
                                   }
                       }
                       for(int i=0;i<str.length()-1;i++)
                                   {
                                               if(che[0]!=' ')
                                               {
                                                           che[0]=(char) (che[0]-32);
                                               }
                                              
                                               if(che[i]==' ')
                                               {
                                                          char a=che[i+1];
                                                           if(a>=97 && a<=122)
                                                           {
                                                                       che[i+1]=(char) (che[i+1]-32);
                                                           }
                                               }
                                  
                       System.out.print(che[i]);
                       }
                       System.out.print(che[str.length()-1]);
                                  
           }
                       public void LetterChanges(String str)
                       {
                                   int a=0;
                                   char[] cha=new char[str.length()];
                                   for(int i=0;i<str.length();i++)
                                   {
                                               cha[i]=str.charAt(i);
                                              
                                   }
                                   for(int i=0;i<str.length();i++)
                                   {
                                               if(cha[i]=='a' || cha[i]=='e' || cha[i]=='i' ||  cha[i]=='o' || cha[i]=='u'  )
                                               {
                                                           cha[i]=(char)(cha[i]-32);
                                               }
                                               else if(cha[i]=='A' || cha[i]=='E'|| cha[i]=='I' || cha[i]=='O' || cha[i]=='U')
                                               {
                                                           cha[i]=cha[i];
                                               }
                                               else
                                               {
                                                           if(cha[i]=='z') cha[i]='a';
                                                           else if(cha[i]=='Z') cha[i]='A';
                                                           else
                                                           {
                                                                       cha[i]=(char)(cha[i]+1);
                                                           }
                                               }
                                               System.out.print(cha[i]);
                                   }
                       }
                       public void ReverseString(String str)
                       {
                                   char cha[]=new char[str.length()];
                                   for(int i=0;i<str.length();i++)
                                   {
                                               cha[i]=str.charAt(str.length()-i-1);
                                               System.out.print(cha[i]);
                                   }
                       }
                       
                       public boolean anagram(String str1, String str2)
                   	{
                   		
                   			  if (str1.length() != str2.length())
                   			   return false;
            
                   			  boolean anagram1 = true;

                   			  for (int i = 0; i < str1.length(); i++) {
                   			   if (str2.indexOf(str1.charAt(i)) == -1)
                   			    anagram1 = false;
                   			  }
                              return anagram1;
                   	 }
                       
                       
    
	public static void main(String[] args) {
		Assignments obj=new Assignments();
		//obj.Primefactor();
	      obj.AlphabetSoup("asif");
      //  obj.findFactorial(5);	
		//boolean a=obj.anagram("angel", "glean");
	     // System.out.print(a);
       // obj.LetterCapitalize("hey what is your name");
		//obj.ReverseString("Hello world and Coders");
		//obj.LetterChanges("whtsupp");

	}

}
