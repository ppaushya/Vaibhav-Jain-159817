package com.capg.BankingVJSpringBoot.controller;

import java.time.Instant;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.BankingVJSpringBoot.model.Account;
import com.capg.BankingVJSpringBoot.model.Customer;
import com.capg.BankingVJSpringBoot.model.Message;
import com.capg.BankingVJSpringBoot.service.IAccountService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class AccountController {
	
	@Autowired
	private IAccountService accountService;
	
	@PostMapping(value = "/account/{customerId}")
	public ResponseEntity<Message> insertAccount(@RequestBody Account account,@PathVariable Long customerId) {
		Customer cBean = new Customer();
		cBean.setCustomerId(customerId);
		account.setCustomer(cBean);
		account.setOpeningDate(Date.from(Instant.now()));
		
		boolean s = accountService.addAccount(account);
		
		if (!s) {
			ResponseEntity<Message> responseEntity = new ResponseEntity<Message>(new Message("Account creation falied",false), HttpStatus.INTERNAL_SERVER_ERROR);
			return responseEntity;
		}
		ResponseEntity<Message> responseEntity = new ResponseEntity<Message>(new Message("Account created successfully",true), HttpStatus.OK);
		return responseEntity;
	}
	
	@GetMapping(value = "/account/{customerId}")
	public ResponseEntity<List<Account>> getAccounts(@PathVariable Long customerId) {
		
		List<Account> list = accountService.getAccountByCustomerCustomerId(customerId);
		
		if (list==null) {
			new ResponseEntity("No account found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Account>>(list, HttpStatus.OK);
	}
	
	@GetMapping(value = "/account/all")
	public ResponseEntity<List<Account>> getAllAccounts() {
		
		List<Account> list = accountService.getAllAccounts();
		
		if (list==null) {
			new ResponseEntity("No account found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Account>>(list, HttpStatus.OK);
	}
	

}
