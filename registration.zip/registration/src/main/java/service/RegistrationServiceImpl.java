package service;

import org.apache.log4j.Logger;
import dao.IRegistrationDao;
import dao.RegistrationDaoImpl;
import exception.InvalidAgeException;
import model.Registration;

public class RegistrationServiceImpl implements IRegistrationService{

	final static Logger logger=Logger.getLogger(RegistrationDaoImpl.class);
	
	private IRegistrationDao registrationDao = new RegistrationDaoImpl();
	
	public RegistrationServiceImpl() {
		
	}
	
	public RegistrationServiceImpl(IRegistrationDao registrationDao) {
		this.registrationDao = registrationDao;
	}
	
	@Override
	public Registration createRegistration(Registration registration) throws InvalidAgeException {
		if(registration==null) {
			logger.error("IllegalArgumentException");
			throw new IllegalArgumentException();
		}
		if(registration.getAge()<5) {
			logger.error("InvalidAgeException at age="+registration.getAge());
			throw new InvalidAgeException("Invalid age.");
		}
		
		double actualFees = getActualFees(registration.getRegistrationFee(), registration.getAge());
		registration.setRegFeePaid(actualFees);
		
		return registrationDao.createRegistration(registration);
	}
	
	public double getActualFees(double fees,int age) {
		double rate;
		if(age<=18) {
			rate = 0;
		}else if (age<=25) {
			rate = 0.10;
		}else if (age<=50) {
			rate = 0.20;
		}else {
			rate = 0.30;
		}
		return fees*(1+rate);
	}

	@Override
	public void createTable() {

		registrationDao.createTable();
		
	}

}
