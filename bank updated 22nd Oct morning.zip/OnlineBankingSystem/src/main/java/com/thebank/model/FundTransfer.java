package com.thebank.model;

import java.util.Date;

public class FundTransfer {

	private long fundTranferId;
	private long accountId;
	private long payeeAccountId;
	private Date dateOfTransfer;
	private double transferAmount;
	
	public FundTransfer() {
		super();
	}
	public long getFundTranferId() {
		return fundTranferId;
	}
	public void setFundTranferId(long fundTranferId) {
		this.fundTranferId = fundTranferId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(long payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public Date getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(Date dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public double getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(double transferAmount) {
		this.transferAmount = transferAmount;
	}
	public FundTransfer(long accountId, long payeeAccountId, Date dateOfTransfer, double transferAmount) {
		super();
		this.accountId = accountId;
		this.payeeAccountId = payeeAccountId;
		this.dateOfTransfer = dateOfTransfer;
		this.transferAmount = transferAmount;
	}
}
