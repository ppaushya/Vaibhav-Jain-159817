package org.capg.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.capg.model.Account;
import org.capg.model.Transaction;

public interface ITransactionDao {

	public boolean createTransaction(Transaction transaction);

	public boolean createFundsTransaction(Transaction transaction);

	public List<Transaction> getTransactionsForCustomer(int custId, LocalDate fromDate, LocalDate toDate);

	public Map<Account, Double> getCurrentBalance(int custId);

}
