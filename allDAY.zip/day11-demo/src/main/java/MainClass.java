
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Sender<Integer,Double> str=new Sender<>();
          str.setMessage(23);
          str.setDescription(4545.34);
          System.out.println(str.getMessage()+"\n"+str.getDescription());
          
         /* Sender<Integer> str1=new Sender<>();
          str1.setMessage(123);
          System.out.println(str1.getMessage());*/
	}

}
