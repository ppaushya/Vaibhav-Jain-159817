import org.cap.Account;
import org.cap.Customer;
public class AccountTransaction {
public Account findAccount(long accountNo,Customer customer) {
		
		
		for(Account account:customer.getAccount()) {
			if(account!=null) {
				if(account.getAccountNo()==accountNo) {
					return account;
				}
			}
		}
		
		return null;

  }
}
