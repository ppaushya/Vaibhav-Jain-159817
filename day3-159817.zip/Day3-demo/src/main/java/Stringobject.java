import java.util.Scanner;

public class Stringobject {

	String[] myStr;
	public void acceptString(int size)
	{
		Scanner sc=new Scanner(System.in);
		myStr=new String[size];
		
		System.out.println("Enter "+ size + " elements");
	     for(int i=0;i<size;i++)
	    	 myStr[i]=sc.nextLine();
	     sc.close();
	}
			
	public void printString()
	{
		for(int i=0;i<myStr.length;i++)
			System.out.println(myStr[i]);
	}
	
	public void reverseString(String arr[],int start,int end)
	{
		String temp;
		if(start>=end)
		 return ;
		temp=arr[start];
		arr[start]=arr[end];
		arr[end]=temp;
		reverseString(arr,start+1,end-1);
	}
	 public void sortArray()
	    {	
		 for(int i=0;i<myStr.length;i++)
	    	{
	    		for(int j=i+1;j<myStr.length;j++)
	    		{
	    			 if(myStr[i].compareTo(myStr[j])>1)
	    			{
	    				String temp=myStr[i];
	    				myStr[i]=myStr[j];
	    				myStr[j]=temp;
	    			}
	    			
	    		}
	    	}
	    }
	    
			
	
	       public static void main(String[] args) {
		     Stringobject obj=new Stringobject();
		     obj.acceptString(5);
		     obj.printString();
		     obj.reverseString(obj.myStr,0,4);
		     System.out.println("Reversed Array : ");
		     obj.printString();
		     obj.sortArray();
		     System.out.println("Sorted Array : ");
		     obj.printString();


	}

}
