package Exercise;

public class OrdinaryClass extends Calls{

	/*public OrdinaryClass() {
		super();
	}*/
	public OrdinaryClass(int hrs) {
		super(hrs);
	}
	public int charge(int hrs)
	{
		return 2*hrs;
	}
}
