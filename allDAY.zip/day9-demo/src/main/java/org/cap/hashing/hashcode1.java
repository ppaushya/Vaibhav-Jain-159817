package org.cap.hashing;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class hashcode1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> hash=new TreeSet<>();
		hash.add(1);
		hash.add(2);
		hash.add(3);
		hash.add(3);
		//hash.add(null);
		System.out.println(hash);
		

	}

}
