package Practice;
//encapsulation
public class Student {

	private int studentId;
	private String fName;
	private String lName;
	private double regFee;
	
	
	public Student() {
		super();
	}


	public Student(int studentId, String fName, String lName, double regFee) {
		super();
		this.studentId = studentId;
		this.fName = fName;
		this.lName = lName;
		this.regFee = regFee;
	}


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getfName() {
		return fName;
	}


	public void setfName(String fName) {
		this.fName = fName;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}


	public double getRegFee() {
		return regFee;
	}


	public void setRegFee(double regFee) {
		this.regFee = regFee;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student obj=new Student(1001,"abc","xyz",6000);
		/*obj.setStudentId(1001);
		obj.setfName("abc");
		obj.setlName("xyz");
		obj.setRegFee(6000);*/
		System.out.println(obj.getStudentId()+" "+obj.getfName()+" "+obj.getlName()+" "+obj.getRegFee());

	}

}
