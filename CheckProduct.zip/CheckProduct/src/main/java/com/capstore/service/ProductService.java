package com.capstore.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.IProductDao;
import com.capstore.model.Product;

@Service("productService")
public class ProductService implements IProductService{

	@Autowired
	private IProductDao productDao;
	
	@Override
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}

	@Override
	public List<Product> sortBestSeller(String category) {
		List<Product> products= productDao.findByProductCategoryOrderByProductsSoldDesc(category);
		return products;
	}

	@Override
	public Map<String, Integer> getBestSellerId() {
		List<Object[]> data=productDao.getBestSellerId();
		Map<String, Integer> bestSellerInfo=new HashMap<>();
		for(Object[] object:data)	{
			bestSellerInfo.put((String)object[0], (Integer)object[1]);
		}
		return bestSellerInfo;
	}


	@Override
	public Map<String, Long> getProductQuantity() {
		List<Object[]> data=productDao.getProductQuantity();
		Map<String, Long> productQuantityInfo=new HashMap<>();
		for(Object[] object:data)	{
			productQuantityInfo.put((String)object[0], (Long)object[1]);
		}
		return productQuantityInfo;
	}

	@Override
	public Map<String, Long> getProductSales() {
		List<Object[]> data=productDao.getProductSales();
		Map<String, Long> productSalesInfo=new HashMap<>();
		for(Object[] object:data)	{
			productSalesInfo.put((String)object[0], (Long)object[1]);
		}
		return productSalesInfo;
	}
	
	

}
