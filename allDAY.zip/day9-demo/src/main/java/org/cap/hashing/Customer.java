package org.cap.hashing;

public class Customer implements Comparable<Customer> {
	private int custID;
	private String custName;
	private String emailID;
	private long mobileNo;
	public Customer()
	{
		
	}
	
	public Customer(int custID, String custName, String emailID, long mobileNo) {
		super();
		this.custID = custID;
		this.custName = custName;
		this.emailID = emailID;
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "Customer [custID=" + custID + ", custName=" + custName + ", emailID=" + emailID + ", mobileNo="
				+ mobileNo + "]";
	}
	

	public int getCustID() {
		return custID;
	}

	public void setCustID(int custID) {
		this.custID = custID;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + custID;
		result = prime * result + ((custName == null) ? 0 : custName.hashCode());
		result = prime * result + ((emailID == null) ? 0 : emailID.hashCode());
		result = prime * result + (int) (mobileNo ^ (mobileNo >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (custID != other.custID)
			return false;
		if (custName == null) {
			if (other.custName != null)
				return false;
		} else if (!custName.equals(other.custName))
			return false;
		if (emailID == null) {
			if (other.emailID != null)
				return false;
		} else if (!emailID.equals(other.emailID))
			return false;
		if (mobileNo != other.mobileNo)
			return false;
		return true;
	}

	@Override
	public int compareTo(Customer o) {
		// TODO Auto-generated method stub
		if(this.getCustID()>o.getCustID())
			return 1;
		else if(this.getCustID()<o.getCustID())
			return -1;
		else 
			return 0;
		}
		
	}
	
	
	


