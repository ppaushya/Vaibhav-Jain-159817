package org.capg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.capg.dao.ITransactionDao;
import org.capg.dao.TransactionDaoImpl;
import org.capg.model.Account;
import org.capg.model.Transaction;

public class TransactionServiceImpl implements ITransactionService {
	
	ITransactionDao transactionDao=new TransactionDaoImpl();
	
	@Override
	public boolean createTransaction(Transaction transaction) {
		 return transactionDao.createTransaction(transaction);
		
	}

	@Override
	public boolean createFundsTransaction(Transaction transaction) {
		return transactionDao.createFundsTransaction(transaction);
	}

	@Override
	public List<Transaction> getTransactionsForCustomer(int custId, LocalDate fromDate, LocalDate toDate) {
		return transactionDao.getTransactionsForCustomer(custId, fromDate, toDate);
	}

	@Override
	public Map<Account, Double> getCurrentBalance(int custId) {
		
		return transactionDao.getCurrentBalance(custId);
	}


}
