package org.cap.game.test;

import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.*;

import org.cap.game.dao.IRegistrationDao;
import org.cap.game.exception.InvalidAgeException;
import org.cap.game.model.Registration;
import org.cap.game.service.IRegistrationService;
import org.cap.game.service.RegistrationServiceImpl;
import org.cap.game.view.UserInteraction;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.junit.Before;

import org.junit.Test;


import java.lang.IllegalArgumentException;



public class RegistrationServiceTest {
	
	@Mock
	IRegistrationDao registrationDao;

	static IRegistrationService registrationServices;
	
@Before
public void init()	{
	MockitoAnnotations.initMocks(this);
	registrationServices=new RegistrationServiceImpl(registrationDao);
}
	@Test(expected=IllegalArgumentException.class)
public void test_null_registration_creation() throws InvalidAgeException {
		Registration registration=new Registration();
		
		RegistrationServiceImpl registrationServices=new RegistrationServiceImpl();
		registration=null;
		registrationServices.createRegistration(registration);
		
	}

	@Test(expected=InvalidAgeException.class)
public void test_invalid_age_registration() throws InvalidAgeException {
		Registration registration=new Registration(10,"Sam","9898554687",200.0,-5,0.0);
		
		registrationServices.createRegistration(registration);
		
	}


	@Test
	public void test_createRegistration_successful() throws InvalidAgeException	{
		Registration registration=new Registration(10,"Sam","9898554687",200.0,25,0.0);
		
		Mockito.when(registrationDao.createRegistration(registration)).thenReturn(registration);
		registrationServices.createRegistration(registration);
		
		Mockito.verify(registrationDao).createRegistration(registration);
		
	}
	/*
	@Test
	public void test_calculateCommission_method(){
		UserInteraction ui = new UserInteraction();
		assertEquals(0, ui.calculateCommission(10, 100),0.0);
		assertEquals(10, ui.calculateCommission(20, 100),0.0);
		assertEquals(20, ui.calculateCommission(28, 100),0.0);
		assertEquals(30, ui.calculateCommission(55, 100),0.0);
		assertEquals(20, ui.calculateCommission(35, 100),0.0);
	}
*/
}
