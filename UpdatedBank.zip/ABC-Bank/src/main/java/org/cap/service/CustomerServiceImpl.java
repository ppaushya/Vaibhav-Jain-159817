package org.cap.service;

import java.time.LocalDate;

import java.util.List;
import java.util.Set;

import org.cap.dao.CustomerDaoImpl;
import org.cap.dao.iCustomerDao;
import org.cap.model.Account;
import org.cap.model.Customer;

public class CustomerServiceImpl implements ICustomerService {

    private iCustomerDao customerDao=new CustomerDaoImpl();
	
	private boolean isValidCustomer(Customer customer)
	{
		boolean flag=false;
		if(customer.getDateofBirth().isBefore(LocalDate.now())) {
			if(customer.getMobileNo().matches("[789]{1}[0-9]{9}"))
                flag=true;
             else
                flag=false;
		}else flag=false;
		return flag;
	}

	@Override
	public List<Customer> getAllCustomer() {
		
		return customerDao.getAllCustomers();
	}

	@Override
	public void CreateCustomers(Customer customer) {
		if(isValidCustomer(customer))
		{
			customerDao.CreateCustomer(customer);
		}
		
	}

	@Override
	public Customer ifFound(int customerID) {
		// TODO Auto-generated method stub
		return customerDao.ifFound(customerID);
	}

	@Override
	public void addAccount(Customer customer, Account account) {
	    
		customerDao.addAccount(customer,account);
	}

	/*@Override
	public void getAccountDetails(Set<Account> account) {
	      customerDao.setAccountDetails(account); 
		
	}*/

	
}

