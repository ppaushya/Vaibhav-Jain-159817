package service;

import exception.InvalidAgeException;
import model.Registration;

public interface IRegistrationService {

	public void createTable();
	public Registration createRegistration(Registration registration) throws InvalidAgeException ;
}
