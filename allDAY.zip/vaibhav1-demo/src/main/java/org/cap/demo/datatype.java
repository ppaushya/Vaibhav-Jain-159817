package org.cap.demo;

public class datatype {
	//instance variable
	int count;
	char ch;
	boolean flag;
	byte num;
	float pi;
    
	public static void main(String[] args) {
		 int mynum=800;
		datatype obj=new datatype();
   System.out.println(obj.count);
   System.out.println(obj.flag);
   System.out.println(obj.ch);
   System.out.println(obj.num);
   System.out.println(obj.pi);
   System.out.println("mynum=" +mynum);
   // TODO Auto-generated method stub
     System.gc();
	}

}
