package org.cap.hashing;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Bootclass {

	public static void main(String[] args) {
		Map<Customer,Address> maps=new TreeMap<>();
		maps.put(new Customer(101,"Joe","dfd@gmail.com",46564545), new Address("234 Street","balaji","mumbai","Maharashtra"));
		maps.put(new Customer(104,"Paras","rhgfxc@gmail.com",345645745), new Address("867 narindra","colony","bathinda","punjab"));
		maps.put(new Customer(102,"Jone","erwetwe@gmail.com",54656756), new Address("786 Street","guru nanak","delhi","new delhi"));
		maps.put(new Customer(103,"Nicky","xcvbxcv@gmail.com",97867), new Address("568990 Street","bulathry","jaipur","rajasthan"));
		maps.put(new Customer(110,"Paras","rhgfxc@gmail.com",345645745), new Address("867 narindra","colony","bathinda","punjab"));
		maps.put(new Customer(160,"Paras","rhgfxc@gmail.com",345645745), new Address("867 narindra","colony","bathinda","punjab"));

		maps.put(new Customer(104,"Paras","rhgfxc@gmail.com",345645745), new Address("867 narindra","colony","bathinda","punjab"));
		//System.out.println(maps+"\n");
        Set<Customer> set= maps.keySet();
        Iterator<Customer> itr=set.iterator();
        while(itr.hasNext())
        {
        Customer key=itr.next();
        System.out.println(key+"-->"+maps.get(key));

        }
	}

}
