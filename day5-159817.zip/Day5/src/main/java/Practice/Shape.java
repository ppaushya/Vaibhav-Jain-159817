//abstract example

package Practice;

public abstract class Shape {

	int width;
	int height;
	
	public Shape() {
		super();
		System.out.println("Shape class--no argument constructor");
	}
	
	public Shape(int width, int height) {
		super();
		System.out.println("Shape class--full argument constructor");

		this.width = width;
		this.height = height;
	}

	public void info()
	{
		System.out.println("Shape Info");;
		
	}
	//abstract
	public abstract void draw();
	
	

}
