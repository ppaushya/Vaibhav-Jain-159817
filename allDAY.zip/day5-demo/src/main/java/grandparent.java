
public class grandparent {
	
	protected int num=1000;
	

	public grandparent(int num) {
		
		this.num = num;
	}
	public void show()
	{
		System.out.println(num);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
