package dao;

import model.Registration;

public interface IRegistrationDao {

	public Registration createRegistration(Registration registration);

	public void createTable();
}
