
public class Mainmethod1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         String Str="Tom";
         String mystr=new String("Tom");
         String Str1="Tom";
         String mystr1=new String("Tom");
         System.out.println(Str==mystr);
         System.out.println(Str.equals(mystr));
         System.out.println(mystr==Str1);
         System.out.println(Str1.equals(mystr));
         System.out.println(mystr==mystr1);
         System.out.println(mystr1.equals(mystr));
		
	}

}
