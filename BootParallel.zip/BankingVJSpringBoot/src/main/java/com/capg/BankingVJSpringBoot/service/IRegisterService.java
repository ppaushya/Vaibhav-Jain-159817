package com.capg.BankingVJSpringBoot.service;

import com.capg.BankingVJSpringBoot.model.Customer;

public interface IRegisterService {

	public void registerCustomer(Customer customer);
	
	

}
