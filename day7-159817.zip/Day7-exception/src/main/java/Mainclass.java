
public class Mainclass {

	public static void main(String[] args) {
	      Child ch=new Child();
	      ch.show();

	}

}
