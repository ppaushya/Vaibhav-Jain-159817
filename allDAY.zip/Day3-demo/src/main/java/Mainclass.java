
public class Mainclass {
	Employee[] employees;
	  public void acceptEmployee(int size)
	  {
		  employees=new Employee[size];
        for(int i=0;i<size;i++)
        {
      	  employees[i]=new Employee();
      	  employees[i].getEmployeedetails();
        }
	  }
	  
	public void printEmployeedetails()
	{
		for(int i=0;i<employees.length;i++) {
		   System.out.println();
			employees[i].printdetails();
	}
}
	public void sortEmployees()	
	{
		Employee temp;
		for(int i=0;i<employees.length;i++)
			 for(int j=i+1;j<employees.length;j++)
			 {
				if(employees[i].empID>employees[j].empID)
				{
					 temp=employees[i];
    				employees[i]=employees[j];
    				employees[j]=temp;
				}
			 }
	}

	public static void main(String[] args) {
		

	}

}
