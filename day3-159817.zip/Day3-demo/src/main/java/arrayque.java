import java.util.Scanner;

public class arrayque {
	
	int[] myarr;
	
	public void getArray(int size)
	{
	   Scanner sc=new Scanner(System.in);
		System.out.println("enter  "+ size +" Array elements");
		myarr=new int[size];
		for(int i=0;i<size;i++)
			myarr[i]=sc.nextInt();
		sc.close();
	}
    public void printArray()
    {
    	for(int i=0;i<myarr.length;i++)
    		System.out.println(myarr[i]);
    }
    public void reverseArray(int arr[],int start,int end)
    {
    	 {
    	        int temp;
    	        if (start >= end)
    	            return;
    	        temp = arr[start];
    	        arr[start] = arr[end];
    	        arr[end] = temp;
    	        reverseArray(arr, start+1, end-1);
    	    }
    		
    }
    
    public void sortArray()
    {
    	for(int i=0;i<myarr.length;i++)
    	{
    		for(int j=i+1;j<myarr.length;j++)
    		{
    			if(myarr[i]>myarr[j])
    			{
    				int temp=myarr[i];
    				myarr[i]=myarr[j];
    				myarr[j]=temp;
    			}
    			
    		}
    	}
    }
    
    public int biggestNo()
    {
      int max=myarr[0];
    	for(int i=1;i<myarr.length;i++)
      {
    	 if(myarr[i]>max)
    	 {
    		 max=myarr[i];
    	 }
    	
      }
    	return max;
    }
    
    public int smallestNo()
    {
      int min=myarr[0];
    	for(int i=0;i<myarr.length;i++)
      {
    	 if(myarr[i]<min)
    	 {
    		 min=myarr[i];
    	 }
    	
      }
    	return min;
    }
    
    public void evenNumber()
    {
    	int sum=0;
    	int[] even=new int[5];
    	for(int i=0;i<myarr.length;i++)
    	{
    		if(myarr[i]%2==0)
    		{
    			even[i]=myarr[i];
                  System.out.println();
    			System.out.print(even[i] +" ");
    			sum=sum+myarr[i];
    			
    		}
    	}
    	System.out.println("\nSum: "+ sum);
    }
    
	
    public static void main(String[] args) {
		arrayque obj= new arrayque();
		obj.getArray(5);
		obj.printArray();
		//obj.reverseArray(obj.myarr,0,9);
		//System.out.println("Reversed Array is :");
		//obj.printArray();
		//System.out.println("Sorted Array is :");
	//	obj.sortArray();
       // obj.printArray();
	  //    System.out.println("Biggest element in Array: " );
	   //   int c=obj.biggestNo();
	   //   System.out.println(c);
		// System.out.println("Smallest element in Array: " );
	    //  int d=obj.smallestNo();
	    //  System.out.println(d);
		obj.evenNumber();
	     
	}

}
