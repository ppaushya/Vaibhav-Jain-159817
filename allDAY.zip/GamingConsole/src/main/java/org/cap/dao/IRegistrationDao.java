package org.cap.dao;

import org.cap.model.Registration;

public interface IRegistrationDao {

	public void createCustomer(Registration customer);
	

}
