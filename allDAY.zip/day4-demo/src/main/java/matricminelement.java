import java.util.Scanner;

public class matricminelement {
	
	int[][] arr;
	public void minMissing2d()
			{
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter the no. of Rows: ");
				int row=sc.nextInt();
				System.out.println("Enter the no. of Coloums: ");
				int col=sc.nextInt();
		        arr= new int[row][col];
		    	System.out.println("Enter the elements");
		        for(int k=0;k<row;k++)
				{
					for(int i=0;i<col;i++)
					{
						arr[k][i]=sc.nextInt();
					}
				}
				System.out.println("Sorting");
				for(int k=0;k<row;k++)
				{
					for(int i=0;i<col;i++)
					{
						for(int j=i+1;j<col;j++)
						{
							if(arr[k][i]>arr[k][j])
							{
								int a=arr[k][i];
								arr[k][i]=arr[k][j];
								arr[k][j]=a;
							}
						}
					}
				}
				
				//
			
				for(int k=0;k<row;k++)
				{
					for(int i=0;i<col;i++)
					{
					
						if((arr[k][i+1]-arr[k][i])>1)
						{
							
							System.out.println(arr[k][i]+1);
							break;
						}
					
					
					}
				}
				
			}
		

	public static void main(String[] args) {
		matricminelement obj=new matricminelement();
		obj.minMissing2d();
		
	}

}
