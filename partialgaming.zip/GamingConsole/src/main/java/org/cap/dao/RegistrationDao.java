package org.cap.dao;

public class RegistrationDao implements IRegistrationDao {
	
	

}
