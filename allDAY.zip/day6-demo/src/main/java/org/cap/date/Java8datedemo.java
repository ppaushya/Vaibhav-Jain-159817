package org.cap.date;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.ZoneId;

public class Java8datedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Instant ins=Instant.now();
		System.out.println(Instant.now());
	//	System.out.println(Instant.MAX);
		//System.out.println(Instant.MIN);
		//System.out.println(ins.MAX);
		//System.out.println(ins.MIN);
		LocalDate date=LocalDate.now();
		System.out.println(date);
		LocalTime tim=LocalTime.now();
		System.out.println(tim);
		LocalDate date1=LocalDate.of(2001,1, 23);
		Period per=Period.between(date, date1);
		System.out.println(per);
		System.out.println(per.getMonths());
		System.out.println(per.getYears());
		System.out.println(per.isNegative());
		LocalTime now=LocalTime.now();
		System.out.println(now);
		LocalTime time=LocalTime.of(10, 50);
		System.out.println(time);
		LocalTime.ofInstant(Instant.now(),ZoneId.of("INDIA"));
		java.util.Set<String> zones=ZoneId.getAvailableZoneIds();
		for(String zone:zones)
		{
			
		}
	
	}   

}
