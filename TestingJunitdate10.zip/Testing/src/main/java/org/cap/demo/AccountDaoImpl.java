package org.cap.demo;

public class AccountDaoImpl implements IAccountDao{

	@Override
	public boolean addAccount(Customer customer) {
	
		return false;
	}

	@Override
	public Account findAccount(int i) {
		// TODO Auto-generated method stub
		return null;
	}
}
