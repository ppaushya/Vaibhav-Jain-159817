package org.cap.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.cap.capgemini.model.Register;
import org.cap.capgemini.service.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

public class RegisterController {
	@Autowired
	private ICustomerService customerService;
	
	private boolean isUpdate = false;
	private Register register;
	
	@RequestMapping("/validateLogin")
	public String validateLogin(ModelMap modelmap,
			@RequestParam("username")String username,
			@RequestParam("password")String password) {
		Register rPojo = new Register();
		rPojo.setEmailId(username);
		rPojo.setPassword(password);
		System.out.println("rpojo");
		System.out.println(rPojo);
		if(customerService.isValidLogin(rPojo)) {
			System.out.println("login s");
			return "redirect:/register";
		}else {
			return "redirect:/";
		}
	}
	
	@RequestMapping("/register")
	public String showRegistrationPage(ModelMap modelmap) {
		List<Register> registers = customerService.getAllRegistration();
		String buttonLabel = "Register";
		if(isUpdate) {
			modelmap.addAttribute("register",register);
			buttonLabel = "Update";
			//modelmap.addAttribute("formAction","updateCustomer/"+registerPojo.getCustomerId());
		}else {
			modelmap.addAttribute("register",new Register());
			//modelmap.addAttribute("formAction","register");
		}

		modelmap.addAttribute("flag",isUpdate);
		modelmap.addAttribute("registerList",registers);
		modelmap.addAttribute("qualificationList",getQualifications());
		modelmap.addAttribute("buttonLabel",buttonLabel);
		return "register";
	}
	
	//@RequestMapping(value= "/register",method=RequestMethod.POST)
	@PostMapping("/register")
	public String registerDetails(ModelMap modelmap,@Valid @ModelAttribute("register") Register register
			,BindingResult result) {
		System.out.println("POST");
		if(!result.hasErrors()) {
			if(isUpdate) {
				System.out.println("UPDATEEEEEEE");
				customerService.updateRegistration(register);
			}else {
				System.out.println("REGISTERRRRRR");
				boolean s = customerService.registerCustomer(register);
				if(!s) {
					System.out.println("Registration error");
				}
			}
			isUpdate = false;
		}else {
			System.out.println("ERRORRRR");
			System.out.println(result.getErrorCount());
		}
		return "redirect:/register";
	}
	

	
	@RequestMapping("/delete/{customerId}")
	public String deleteRegistration(@PathVariable("customerId")Integer customerId) {
		customerService.deleteRegistration(customerId);
		
		return "redirect:/register";
	}
	
	@RequestMapping("/edit/{customerId}")
	public String editRegistration(@PathVariable("customerId")Integer customerId) {
		isUpdate = true;
		register = customerService.findRegistration(customerId);
		System.out.println("edit");
		System.out.println(register);
		return "redirect:/register";
	}
	
	private List<String> getQualifications() {
		List<String> qualificationList = new ArrayList<String>();
		
		qualificationList.add("BTech");
		qualificationList.add("BE");
		qualificationList.add("MBA");
		qualificationList.add("BSc");
		qualificationList.add("BCom");
		
		return qualificationList;
	}

}
