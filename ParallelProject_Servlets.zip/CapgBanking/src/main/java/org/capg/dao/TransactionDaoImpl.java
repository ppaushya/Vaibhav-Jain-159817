package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.capg.model.Account;
import org.capg.model.Transaction;

public class TransactionDaoImpl implements ITransactionDao{
	

	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "navkar");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	

	@Override
	public boolean createTransaction(Transaction transaction) {
		    boolean flag=false;
		    String sql="insert into acc_transaction(transactionDate,fromAccount,toAccount,amount,description,transactionType,customerId) values(?,?,?,?,?,?,?);";
		    try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
		    	
		    	pst.setDate(1, Date.valueOf(transaction.getTransactionDate()));
		    	pst.setInt(2, transaction.getFromAccount());
		    	pst.setInt(3, transaction.getToAccount());
		    	pst.setDouble(4, transaction.getAmount());
		    	pst.setString(5, transaction.getDescription());
		    	pst.setString(6, transaction.getTransactionType());
		    	pst.setInt(7, transaction.getCustomerId());
		    	int count=pst.executeUpdate();
		    	if(count>0)
		    	{
		    		flag=true;
		    	}
		    	else flag=false;
		    	
		    	
		    	
		    	
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return flag;
	}


	@Override
	public boolean createFundsTransaction(Transaction transaction) {
		  boolean flag=false;
		    String sql="insert into acc_transaction(transactionDate,fromAccount,toAccount,amount,description,transactionType,customerId) values(?,?,?,?,?,?,?);";
		    try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
		    	
		    	pst.setDate(1, Date.valueOf(transaction.getTransactionDate()));
		    	pst.setInt(2, transaction.getFromAccount());
		    	pst.setInt(3, transaction.getToAccount());
		    	pst.setDouble(4, transaction.getAmount());
		    	pst.setString(5, transaction.getDescription());
		    	pst.setString(6, transaction.getTransactionType());
		    	pst.setInt(7, transaction.getCustomerId());
		    	int count=pst.executeUpdate();
		    	if(count>0)
		    	{
		    		flag=true;
		    	}
		    	else flag=false;
		    	
		    	
		    	
		    	
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return flag;
	}


	@Override
	public List<Transaction> getTransactionsForCustomer(int custId, LocalDate fromDate, LocalDate toDate) {

		List<Account> accounts=new ArrayList<>();
		IAccountDao accountDao=new AccountDaoImpl();
		accounts=accountDao.getAccountsForCustomer(custId);
		List<Transaction> transactions=new ArrayList<>();
		
		for(Account account:accounts)	{
			
			String sql="select * from acc_transaction where fromAccount="+account.getAccountNumber()+
					" or toAccount="+account.getAccountNumber()+";";
			try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
				
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()) {
					Transaction transaction=new Transaction();

					transaction.setTransactionId(rs.getInt(1));
					transaction.setTransactionDate(rs.getDate(2).toLocalDate());
					transaction.setFromAccount(rs.getInt(3));
					transaction.setToAccount(rs.getInt(4));
					transaction.setAmount(rs.getDouble(5));
					transaction.setDescription(rs.getString(6));
					transaction.setTransactionType(rs.getString(7));
					
					
					if(transaction.getTransactionDate().isAfter(fromDate) && transaction.getTransactionDate().isBefore(toDate)) {
						transactions.add(transaction);
					}
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return transactions;
	}


	@Override
	public Map<Account, Double> getCurrentBalance(int custId) {
		List<Account> accounts=new ArrayList<>();
		IAccountDao accountDao=new AccountDaoImpl();
		accounts=accountDao.getAccountsForCustomer(custId);
		List<Transaction> transactions=new ArrayList<>();
		Map<Account, Double> currentBalance=new HashMap<>();
		
		for(Account account:accounts)	{
			
			double openingBal=account.getOpeningBalance();
			double currentBal=openingBal;
			//System.out.println(currentBal);
			String sql="select * from acc_transaction where fromAccount="+account.getAccountNumber()+
					" or toAccount="+account.getAccountNumber()+";";
			try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
				
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()) {
					Transaction transaction=new Transaction();
					
					transaction.setTransactionId(rs.getInt(1));
					transaction.setTransactionDate(rs.getDate(2).toLocalDate());
					transaction.setFromAccount(rs.getInt(3));
					transaction.setToAccount(rs.getInt(4));
					transaction.setAmount(rs.getDouble(5));
					transaction.setDescription(rs.getString(6));
					transaction.setTransactionType(rs.getString(7));
					
					transactions.add(transaction);
					
					double amt =transaction.getAmount();
					//Calculating current balance
					if(transaction.getToAccount()==account.getAccountNumber() || transaction.getTransactionType().equals("Credit") || transaction.getTransactionType().equals("Funds Transfer") )
						currentBal+=amt;
					else if(transaction.getFromAccount()==account.getAccountNumber() || transaction.getTransactionType().equals("Debit") || transaction.getTransactionType().equals("Funds Transfer"))
						currentBal-=amt;
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			currentBalance.put(account, currentBal);
		}
		
		return currentBalance;
		
	}


	

}
