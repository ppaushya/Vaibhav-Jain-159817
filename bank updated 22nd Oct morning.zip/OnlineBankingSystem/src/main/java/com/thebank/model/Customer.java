package com.thebank.model;

import java.util.List;
import java.util.Set;

public class Customer {
	
	private long customerId;
	private String customerName;
	private String email;
	private String address;
	private String pancard;
	private List<Account> accounts;
	private String mobile;
	
	public Customer() {
		
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email
				+ ", address=" + address + ", pancard=" + pancard + ", accounts=" + accounts + ", mobile=" + mobile
				+ "]";
	}

	public Customer(long customerId, String customerName, String email, String address, String pancard,
			List<Account> accounts, String mobile) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.email = email;
		this.address = address;
		this.pancard = pancard;
		this.accounts = accounts;
		this.mobile = mobile;
	}
}

		