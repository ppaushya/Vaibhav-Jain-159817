package org.cap.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Customer;


import org.cap.model.Address;
//import org.capg.model.Customer;

public class CustomerDaoImpl implements iCustomerDao {
	  private static List<Customer> customers=dummyDB();
	  //Set<Account> account=setAccountDetails(Set<Account> account);
	  
	/*  @Override
	  public void setAccountDetails(Set<Account> account)
	  {
		  
	  }
 */
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customers;
	}

	private static List<Customer> dummyDB() {
		  List<Customer> customers=new ArrayList<>();   
		Address address1=new Address("23,west Car St", "2nd St", "Chennai", "TN", "234442");
		customers.add(new Customer(123,"Jone","Nick","jone@gmail.com","9834344341",LocalDate.of(2010,12,23),address1));
		Address address2=new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", "657657");
		customers.add(new Customer(1090,"Tom","Jerry","tom@gmail.com","9090912345", LocalDate.of(1987, 12, 23),address2));
		return customers;
	}

	@Override
	public void CreateCustomer(Customer customer) {
		customers.add(customer);
		
	}

	@Override
	public Customer ifFound(int customerID) {
		for(Customer customer:getAllCustomers())
		{
			if(customer.getCustomerID()==customerID)
				return (Customer) customer;
		}
		
		return null;
	}

	@Override
	public void addAccount(Customer customer, Account account) {
		customer.getAccounts().add(account);
		
	}
	
	  

}
