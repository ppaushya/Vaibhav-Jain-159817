package org.capg.service;

import org.capg.dao.ITransactionDao;
import org.capg.dao.TransactionDaoImpl;
import org.capg.model.Transaction;

public class TransactionServiceImpl implements ITransactionService {
	
	ITransactionDao transactionDao=new TransactionDaoImpl();
	
	@Override
	public boolean createTransaction(Transaction transaction) {
		 return transactionDao.createTransaction(transaction);
		
	}

	@Override
	public boolean createFundsTransaction(Transaction transaction) {
		return transactionDao.createFundsTransaction(transaction);
	}


}
