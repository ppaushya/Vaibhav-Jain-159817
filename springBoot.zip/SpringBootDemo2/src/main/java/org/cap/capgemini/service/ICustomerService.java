package org.cap.capgemini.service;

import java.util.List;

import javax.validation.Valid;

import org.cap.capgemini.model.Register;


public interface ICustomerService {


	public List<Register> getAllRegistration();

	public void updateRegistration(Register register);

	public boolean registerCustomer(Register register);

	public void deleteRegistration(Integer customerId);

	public Register findRegistration(Integer customerId);

	public boolean isValidLogin(Register rPojo);
}
