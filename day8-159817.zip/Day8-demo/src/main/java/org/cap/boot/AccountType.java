package org.cap.boot;
public enum AccountType {
	
	SAVINGS,CURRENT,RD,FD;

}
