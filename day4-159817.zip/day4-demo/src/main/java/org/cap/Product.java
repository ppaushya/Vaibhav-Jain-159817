package org.cap;

public class Product {
	int productID;
	String productname;
	double price;
	int qty;
	
	public Product(int productID, String productname, double price, int qty) {
		super();
		this.productID = productID;
		this.productname = productname;
		this.price = price;
		this.qty = qty;
	}
            
	
	public Product()
	{
		System.out.println("Default Constructor");
	}
	public Product(int prodID)
	{
		System.out.println("Overloaded Constructor");
		this.productID=prodID;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Product objt=new Product(1001,"sfaf",4500,3);
        System.out.println(objt);
        Product obj1=new Product(1001,"sfaf",4500,3);
        System.out.println(obj1);
      	
	}

}