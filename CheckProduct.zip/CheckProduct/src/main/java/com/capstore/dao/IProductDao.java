package com.capstore.dao;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capstore.model.Product;

@Repository("productDao")
@Transactional
public interface IProductDao extends JpaRepository<Product,Integer> {

	public List<Product> findByProductCategoryOrderByProductsSoldDesc(String category);
	
	@Query("SELECT productCategory, SUM(quantity) FROM"
			+ " Product group by productCategory")
	public List<Object[]> getProductQuantity();
	
	@Query("SELECT productCategory, SUM(productsSold) FROM"
			+ " Product group by productCategory")
	public List<Object[]> getProductSales();
	
	@Query("SELECT productCategory, merchantId FROM Product WHERE productsSold in(SELECT MAX(productsSold) from Product GROUP BY productCategory)")
	public List<Object[]> getBestSellerId();
}
