
public class Switch {
        
	public static void main(String[] args) {
		String name="Jones";
		
		switch(name)
		{
		default:
		case "nehl": {
			System.out.println("one");
			System.out.println("block");
			//break;
		}
		case "jane":
			System.out.println("two");
			//break;
		case "Mehil":
			System.out.println("ten");
			System.out.println("not found");
		}
		// TODO Auto-generated method stub

	}

}
