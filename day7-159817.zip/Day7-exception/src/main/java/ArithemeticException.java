
public class ArithemeticException extends Exception {

}
