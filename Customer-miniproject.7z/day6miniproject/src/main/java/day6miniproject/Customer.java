package day6miniproject;

import java.util.ArrayList;

public class Customer {

	private int customerId;
	
	private String customerName;
	
	private String email,mobileno;
	
	 Address address=new Address();
	 
	  // Account account[]=new Account[5];
	
	 ArrayList<Account> accounts= new ArrayList<>();

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Customer(int customerId, String customerName, String email, String mobileno) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.email = email;
		this.mobileno = mobileno;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}


	
	
	

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Customer()
	{
		
	}
	
}
