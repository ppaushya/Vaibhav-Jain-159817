package org.cap.capgemini.dao;

import java.util.ArrayList;
import java.util.List;


import org.cap.capgemini.model.Register;

import org.springframework.stereotype.Repository;


@Repository("customerDao")
public class CustomerDaoImpl implements ICustomerDao {

	List<Register> register=new ArrayList<>();
	@Override
	public List<Register> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateCustomer(Register register) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean createCustomer(Register register) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void deleteCustomer(Integer customerId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Register findCustomer(Integer customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isValidLogin(Register rPojo) {
		// TODO Auto-generated method stub
		return false;
	}

	
	
	
	
	
	
}
