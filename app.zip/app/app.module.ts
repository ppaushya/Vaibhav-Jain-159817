import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
//import { TestComponent } from './test.component';
import { AppComponent } from './app.component';
import { ProductListComponent } from './Product/product-list.component';
import { ConvertToSpacePipe } from './shared/convert-to-space.pipe';
import { StarComponent } from './shared/star.component';
import { ProductService } from './Product/product.service';
import { HttpClientModule } from '@angular/common/http';
import { ProductDetailComponent } from './products/product-detail.component';
import { RouterModule } from '@angular/router';
import { WelcomeComponent } from './home/welcome.component';

import { RegistrationComponent } from './Registration/registration.component';
import { LoginComponent } from './Login/login.component';
import { MainPageComponent } from './MainPage/mainpage.component';
import { CreateAccountComponent } from './MainPage/CreateAccount.component';
import { DepositWithdrawComponent } from './MainPage/DepositWithdraw.component';
import { FundsTransferComponent } from './MainPage/fundsTransfer.component';
import { TransactionSummaryComponent } from './MainPage/transactionSummary.component';

//import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    RegistrationComponent,LoginComponent,MainPageComponent,CreateAccountComponent,DepositWithdrawComponent,
    FundsTransferComponent,TransactionSummaryComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    RouterModule.forRoot([
       {path:'Login',component:LoginComponent},
       {path:'Registration',component:RegistrationComponent}
       ,{path:'MainPage',component:MainPageComponent}
       ,{path:'Account',component:CreateAccountComponent}
       ,{path:'Deposit',component:DepositWithdrawComponent}
       ,{path:'Fund',component:FundsTransferComponent}
       ,{path:'Transaction',component:TransactionSummaryComponent}

      // ,{path:'welcome',component: WelcomeComponent},
      //  ,{path:'',redirectTo: 'Registration',pathMatch:'full'},
      //  {path:'**',redirectTo:'Capg_Banking',pathMatch:'full'}
     ])
  ],
  providers: [],
  bootstrap: [LoginComponent]
})
export class AppModule { }
