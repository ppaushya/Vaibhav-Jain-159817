package com.thebank.service;

public class UserServiceImpl implements  {

}
