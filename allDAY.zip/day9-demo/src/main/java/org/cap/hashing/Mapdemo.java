package org.cap.hashing;

import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Mapdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Map<Integer,String> maps=new Hashtable<>();
        maps.put(4, "one");
        maps.put(3, "Two");
        maps.put(1, "Three");
        maps.put(2, "Three");
        maps.put(1, "one");
      //  maps.put(null, null);
        maps.put(343, "one");
        maps.put(5443, "twenty");
      //  maps.put(1, null);
        //maps.put(null,"Four");
        System.out.println(maps);
        Set<Integer> set= maps.keySet();
        Iterator<Integer> itr=set.iterator();
        while(itr.hasNext())
        {
        	int key=itr.next();
        	System.out.println(key+"-->"+maps.get(key));
        }
        
        Collection<String> values=maps.values();
        for(String str:values)
        	System.out.println(str);
        
    }

}
