
public class CheckException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=100;
		String num2="10s";
		int result=0;
		try {
		result=num1/Integer.parseInt(num2);
		} 
		catch (ArithmeticException e) 
		{
		//	System.out.println(e.getMessage());
			e.printStackTrace();
		}
		catch(NumberFormatException n){
		   //	System.out.println(n.getMessage());
			n.printStackTrace();
		}
			
		finally {
			System.out.println("Finally block statement");
		}
		System.out.println(result);
		

	}

}
