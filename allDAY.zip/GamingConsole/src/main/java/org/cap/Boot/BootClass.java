package org.cap.Boot;

import java.util.Scanner;

import org.cap.model.Registration;
import org.cap.service.CustomerRegistrationImpl;
import org.cap.service.ICustomerRegistration;
import org.cap.view.UserInteraction;

public class BootClass {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		 UserInteraction userinteraction=new UserInteraction();
		 ICustomerRegistration customerservice=new CustomerRegistrationImpl();
		 int a;
		 String opt;
		 do {
			 System.out.println("Welcome to the Gaming Console!!");
			 System.out.println("1.Customer Registration");
			 System.out.println("2.Exit");
			 a=sc.nextInt();
			 switch(a)
			 {
			 case 1:
				 Registration customer=userinteraction.createCustomer();
				 customerservice.createCustomer(customer);
				 break;
			 case 2:
				 System.exit(0);
			 }
			 System.out.println("\nDo you wish to Continue:y/n");
			 opt=sc.next();
			 
		 }while(opt.charAt(0)=='Y'||opt.charAt(0)=='y');
		 
		 		 
       
	}

}
