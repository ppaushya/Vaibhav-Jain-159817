import java.util.Scanner;

public class multidim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] arr=new int[3][2];
		Scanner sc=new Scanner(System.in);
		/* arr[0][0]=12;
		arr[0][1]=10;
		arr[1][0]=14;
		arr[1][1]=6;
		arr[2][0]=12;
		arr[2][1]=20;*/
		for(int i=0;i<3;i++) 
		{
			for(int j=0;j<2;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		for(int i=0;i<3;i++) 
		{
			for(int j=0;j<2;j++)
			{
				System.out.print(arr[i][j]+ "\t");
			}
			System.out.println();
		}

	}

}
